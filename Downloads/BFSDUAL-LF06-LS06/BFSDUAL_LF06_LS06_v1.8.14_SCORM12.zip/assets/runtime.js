(() => {
  'use strict';
  const packageId = window.GB_PACKAGE_ID;
  const checkCount = Number(window.GB_CHECK_COUNT);
  if (!packageId) throw Error('Die Kennung für die Lernsituation fehlt.');
  const root = new URL('../', document.currentScript.src);
  const localKey = packageId + ':' + root.pathname + (window.BFS_EDITOR?.preview ? ':editor-preview' : '');
  const validPages = new Set(['index', 'handlungssituation', 'informieren', 'begriffstraining', 'planen', 'entscheiden', 'durchfuehren', 'bewerten', 'reflektieren', 'materialien', 'ls-glossar', 'peer-check', 'feedback']);
  const validPath = value => ['A', 'B', 'C'].includes(value);
  const clone = value => JSON.parse(JSON.stringify(value));
  const trueResult = value => String(value).toLowerCase() === 'true';
  function safePage(value) {
    if (typeof value !== 'string') return 'index.html';
    if (value.startsWith('material/') && value.endsWith('.html')) {
      try {
        const plain = decodeURIComponent(value);
        if (!/[?#:\\]/.test(plain) && plain.split('/').every(part => part && !part.startsWith('.'))) return value;
      } catch { /* Invalid stored path. */ }
    }
    return value.endsWith('.html') && validPages.has(value.slice(0, -5)) ? value : 'index.html';
  }
  function fresh() {
    return {id: packageId, v: 1, page: 'index.html', done: [], responses: {}, path: '', check: null, completed: false};
  }
  function parseState(raw) {
    return window.BFS_RESUME.lesson(raw, fresh(), window.GB_REQUIREMENTS || {}, checkCount, safePage);
  }
  function findAPI(start) {
    let win = start;
    for (let step = 0; win && step < 32; step++) {
      try {
        if (typeof win.API?.LMSInitialize === 'function') return win.API;
        if (win === win.parent) break;
        win = win.parent;
      } catch { break; }
    }
    return null;
  }
  function makeSession() {
    const api = window.BFS_EDITOR?.preview ? null : (findAPI(window) || findAPI(window.opener));
    let state = fresh();
    let initialized = false;
    let readOnly = false;
    let error = '';
    let practiceMessage = '';
    let saving = 0;
    let dirty = false;
    let finished = false;
    let sent = '';
    const observers = new Set();
    const notify = () => observers.forEach(update => update());
    function get(key) {
      const value = api.LMSGetValue(key);
      if (typeof api.LMSGetLastError === 'function' && String(api.LMSGetLastError()) !== '0') throw Error('Moodle konnte den Lernstand nicht lesen.');
      return String(value ?? '');
    }
    function set(key, value) {
      if (!trueResult(api.LMSSetValue(key, value))) throw Error('Moodle hat die Übertragung nicht bestätigt.');
    }
    try {
      if (api) {
        if (!trueResult(api.LMSInitialize(''))) throw Error('Die Verbindung zu Moodle konnte nicht geöffnet werden.');
        initialized = true;
        readOnly = ['review', 'browse'].includes(get('cmi.core.lesson_mode'));
        const saved = get('cmi.suspend_data');
        state = parseState(saved);
        const bookmark = get('cmi.core.lesson_location');
        if (bookmark && safePage(bookmark) === bookmark) state.page = bookmark;
        else if (validPages.has(bookmark)) state.page = bookmark+'.html';
        if (/^m[1-6]\.html$/.test(bookmark)) state.page = 'material/' + bookmark;
        const status = get('cmi.core.lesson_status');
        state.completed ||= ['completed', 'passed'].includes(status);
        // Merely viewing an older compatible attempt need not rewrite its stored bytes.
        if (saved) sent = JSON.stringify(state);
        dirty = !saved && !state.completed && !readOnly;
      } else {
        state = parseState(
          localStorage.getItem(localKey) ||
          (!window.BFS_EDITOR?.preview && localStorage.getItem('bfsdual-preview-v1:' + packageId + ':' + root.pathname)) || ''
        );
      }
    } catch (cause) {
      if (cause instanceof window.BFS_RESUME.StateIssue) {
        practiceMessage = window.BFS_RESUME.practiceNotice(cause, Boolean(api));
      } else {
        readOnly = true;
        error = 'Der Lernstand ist nicht verfügbar. Öffne die Moodle-Aktivität erneut.';
      }
    }
    function flush() {
      clearTimeout(saving);
      if (!dirty || finished || readOnly) return !error;
      if (practiceMessage) {
        dirty = false;
        notify();
        return true;
      }
      try {
        const raw = JSON.stringify(state);
        if (api) {
          if (raw.length > 4096) throw Error('Der Text übersteigt den Speicherplatz in Moodle. Bitte kürze die Leseantworten.');
          if (sent !== raw) {
            set('cmi.suspend_data', raw);
            set('cmi.core.lesson_location', state.page);
            set('cmi.core.score.raw', String(window.BFS_LF06_GRADE(state)));
            set('cmi.core.score.min', '0');
            set('cmi.core.score.max', '100');
            set('cmi.core.lesson_status', state.completed ? 'completed' : 'incomplete');
            set('cmi.core.exit', state.completed ? '' : 'suspend');
            if (!trueResult(api.LMSCommit(''))) throw Error('Moodle hat das Speichern nicht bestätigt.');
          }
        } else {
          localStorage.setItem(localKey, raw);
        }
        dirty = false;
        sent = raw;
        error = '';
      } catch (cause) {
        error = cause.message || 'Der Lernstand konnte nicht gespeichert werden.';
      }
      notify();
      return !error;
    }
    function change(update, delayed = false) {
      if (readOnly || finished || state.completed) return false;
      update(state);
      dirty = true;
      if (!delayed) return flush();
      clearTimeout(saving);
      saving = setTimeout(flush, 350);
      return true;
    }
    function complete() {
      if (state.completed && !dirty) return true;
      if (finished || readOnly) return false;
      state.completed = true;
      dirty = true;
      if (flush()) {
        if (!api || practiceMessage) return true;
        try { finished = trueResult(api.LMSFinish('')); } catch { finished = false; }
        if (finished) return true;
        error = 'Moodle hat den Abschluss noch nicht bestätigt. Öffne das Lernpaket erneut.';
        notify();
        return false;
      }
      state.completed = false;
      dirty = true;
      notify();
      return false;
    }
    window.addEventListener('pagehide', ev => {
      flush();
      if (ev.persisted || !api || !initialized || finished) return;
      try { finished = trueResult(api.LMSFinish('')); } catch { /* LMS window closed. */ }
    });
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(); });
    return {
      read: () => clone(state), change, flush, complete,
      subscribe(fn) { observers.add(fn); return () => observers.delete(fn); },
      get locked() { return readOnly || state.completed || finished; },
      get error() { return error || practiceMessage; },
      get message() {
        if (error || practiceMessage) return error || practiceMessage;
        if (state.completed) return api ? 'In Moodle abgeschlossen.' : 'In diesem Browser abgeschlossen.';
        if (readOnly) return 'Moodle zeigt den Lernstand im Ansichtsmodus.';
        return api ? 'Fortschritt wird in Moodle gespeichert.' : 'Dein Fortschritt wird in diesem Browser gespeichert.';
      }
    };
  }

  const shell = document.querySelector('[data-scorm-frame]');
  let session;
  if (shell) {
    session = makeSession();
    const page = session.read().page;
    if (location.protocol === 'file:') {
      // Local file frames may have separate opaque origins. Use ordinary navigation here.
      location.replace(new URL(page, root));
      return;
    }
    window.GlobalBikeSCORMSession = session;
    function showError() {
      const notice = document.querySelector('[data-shell-status]');
      if (notice) { notice.hidden = !session.error; notice.textContent = session.error; }
    }
    session.subscribe(showError);
    showError();
    shell.src = new URL(page, root).href;
    return;
  }
  try { if (window.parent !== window) session = window.parent.GlobalBikeSCORMSession; } catch { /* External host. */ }
  session ||= makeSession();
  const page = safePage(location.pathname.slice(root.pathname.length));
  const formResponses = [...document.querySelectorAll('[data-response]')];
  const doneBoxes = [...document.querySelectorAll('input[type="checkbox"][data-done]')];
  const pathRadios = [...document.querySelectorAll('[name="lernweg"]')];
  const finishButtons = [...document.querySelectorAll('[data-finish]')];
  const requirements = window.GB_REQUIREMENTS || {common: []};
  const phases = window.BFS_LF06_PHASES;
  const termCheckDone = state => window.BFS_XP.terms.every(({answer,key}, i) =>
    state.check?.[i] === Number(window.BFS_EDITOR?.current.checks[key]?.correct ?? answer));
  function firstLockedPhase(state, target) {
    if (window.BFS_EDITOR?.preview || state.completed) return '';
    for (const phase of Object.keys(phases)) {
      if (phase === target) return '';
      if (phase === 'begriffstraining.html' && !termCheckDone(state)) return phase;
      const ids = [...phases[phase].common, ...(phases[phase][state.path] || [])];
      if (!ids.every(id => state.done.includes(id))) return phase;
    }
    return '';
  }
  if (Object.hasOwn(phases, page)) {
    const fallback = firstLockedPhase(session.read(), page);
    if (fallback) {
      location.replace(new URL(fallback, root));
      return;
    }
  }
  function progress(state) {
    const ids = [...new Set([...(requirements.common || []), ...(requirements[state.path] || [])])];
    const missingResponses = (requirements.responses || []).some(id => !state.responses[id]?.trim());
    const checked = ids.filter(id => state.done.includes(id)).length;
    return {total: ids.length, checked, ready: ids.length > 0 && validPath(state.path) && checked === ids.length && !missingResponses &&
      termCheckDone(state)};
  }
  window.GB = {
    refreshUI: render,
    getPath: () => session.read().path,
    snapshot: () => session.read(),
    answerSituation(id, choice, right) {
      if (!(requirements.responses || []).includes(id) || !(Number.isInteger(choice) && choice >= 0 && choice < 6)) return false;
      return session.change(state => {
        if (state.done.includes(id)) return;
        const old = state.responses[id];
        const first = typeof old === 'string' && old.startsWith('mc:') ? old.split(':')[1] : Number(choice===right);
        state.responses[id] = 'mc:' + first + ':' + choice;
        if (choice===right) state.done.push(id);
      });
    },
    get readOnly() { return session.locked; },
    getCheck: () => session.read().check,
    saveCheck(value) {
      if (!Array.isArray(value) || value.length !== checkCount || !value.every(x => x === null || (Number.isInteger(x) && x >= 0 && x < 6))) return false;
      return session.change(s => {
        s.checkFirst ||= Array(checkCount).fill(null);
        value.forEach((choice, i) => { if (s.checkFirst[i] == null) s.checkFirst[i]=choice; });
        s.check = value.slice();
      });
    }
  };
  function toggleSection(el, visible) {
    el.hidden = !visible;
    if (!visible) {
      // The master uses !important for layout grids; hidden variants must stay out of that grid.
      el.style.setProperty('display', 'none', 'important');
      el.dataset.gbHidden = '';
    } else if (el.hasAttribute('data-gb-hidden')) {
      el.style.removeProperty('display');
      delete el.dataset.gbHidden;
    }
  }
  function render() {
    const state = session.read();
    const {total, checked, ready} = progress(state);
    document.querySelectorAll('[data-progress]').forEach(el => {
      el.textContent = state.completed ? 'Lernpaket abgeschlossen' : `${checked} von ${total} Pflichtaufgaben erledigt`;
    });
    document.querySelectorAll('[data-progress-bar]').forEach(el => { el.max = Math.max(total, 1); el.value = checked; });
    document.querySelectorAll('[data-runtime-status]').forEach(el => { el.textContent = session.message; });
    formResponses.forEach(el => { el.readOnly = session.locked; });
    doneBoxes.forEach(el => {
      el.checked = state.done.includes(el.dataset.done);
      const field = formResponses.find(item => item.dataset.response === el.dataset.done);
      el.disabled = session.locked || (el.dataset.done === requirements.choice && !validPath(state.path)) || Boolean(field && !field.value.trim());
    });
    pathRadios.forEach(el => { el.checked = el.value === state.path; el.disabled = session.locked; });
    document.querySelectorAll('[data-require-path]').forEach(el => { toggleSection(el, Boolean(state.path)); });
    const choose = document.getElementById('wahlhinweis');
    if (choose) toggleSection(choose, !state.path);
    document.querySelectorAll('[data-path]').forEach(el => { toggleSection(el, state.path === el.dataset.path); });
    document.querySelectorAll('[data-current-path]').forEach(el => { el.textContent = state.path ? `Lernpaket ${state.path}` : 'Lernpaket wählen'; });
    finishButtons.forEach(el => {
      el.disabled = state.completed || !ready || session.locked;
      el.textContent = state.completed ? 'Lernpaket abgeschlossen' : 'Lernpaket abschließen';
    });
    document.querySelectorAll('[data-finish-hint]').forEach(el => {
      el.textContent = state.completed ? session.message : ready ? 'Alle Pflichtaufgaben sind erledigt. Du kannst den Abschluss jetzt bestätigen.' : `Setze die Häkchen bei deinen erledigten Pflichtaufgaben. ${total - checked} noch offen.`;
    });
    for (const link of document.querySelectorAll('a[data-learning-page], .page-turn a, .bfs-term-launch')) {
      const dest = new URL(link.href, location.href).pathname.split('/').at(-1);
      if (!Object.hasOwn(phases, dest)) continue;
      const blocked = firstLockedPhase(state, dest);
      link.classList.toggle('bfs-progress-locked', Boolean(blocked));
      if (blocked) {
        link.setAttribute('aria-disabled', 'true');
        link.title = 'Bearbeite die vorherigen Abschnitte.';
      } else if (!link.classList.contains('bfs-path-locked')) {
        link.removeAttribute('aria-disabled');
        link.removeAttribute('title');
      }
    }
    window.dispatchEvent(new Event('bfs-progress'));
  }
  document.addEventListener('click', event => {
    const locked = event.target.closest('a.bfs-progress-locked');
    if (!locked) return;
    event.preventDefault();
    const status = document.querySelector('[data-runtime-status]');
    const dest = new URL(locked.href, location.href).pathname.split('/').at(-1);
    const earlier = firstLockedPhase(session.read(), dest);
    if (status && earlier) status.textContent = 'Bearbeite zuerst den Abschnitt „' +
      (document.querySelector('a[data-learning-page="' + earlier + '"]')?.textContent.trim()
       || 'Fachbegriffscheck') + '“.';
  }, true);
  const initial = session.read();
  formResponses.forEach(el => {
    el.maxLength = el.maxLength > 0 ? Math.min(el.maxLength, 240) : 240;
    el.value = initial.responses[el.dataset.response] || '';
    el.addEventListener('input', () => {
      session.change(s => {
        s.responses[el.dataset.response] = el.value.slice(0, 240);
        if (!el.value.trim()) s.done = s.done.filter(id => id !== el.dataset.response);
      }, true);
      render();
    });
    el.addEventListener('change', () => session.flush());
  });
  doneBoxes.forEach(el => el.addEventListener('change', () => {
    session.change(s => {
      const ids = new Set(s.done);
      if (el.checked) ids.add(el.dataset.done); else ids.delete(el.dataset.done);
      s.done = [...ids];
    });
  }));
  pathRadios.forEach(el => el.addEventListener('change', () => {
    if (el.checked && validPath(el.value)) session.change(s => { s.path = el.value; });
  }));
  finishButtons.forEach(el => el.addEventListener('click', () => { if (progress(session.read()).ready) session.complete(); }));
  const unsubscribe = session.subscribe(render);
  window.addEventListener('pagehide', () => { session.flush(); unsubscribe(); }, {once: true});
  session.change(s => { s.page = page; });
  render();
})();
/* Aufgabenfokus innerhalb der bestehenden Phasenseite. */
((options)=>{'use strict';
const D=window.SOZPAED,P=window.SOZ_PROGRESS;
if(!D||!P||document.body.dataset.teacher||!['informieren.html','planen.html','entscheiden.html','durchfuehren.html','bewerten.html','reflektieren.html'].includes(document.body.dataset.page))return;
const returnTask=new URLSearchParams(location.search).get('aufgabe');const returnMode=window.SOZ_PROGRESS_META?.tasks[returnTask]?.mode;if(returnMode&&Number(document.body.dataset.mode)!==returnMode)window.SOZ_API.setMode(returnMode);
const cards=[...document.querySelectorAll('.lesson-content .assignment-frame')];if(!cards.length)return;
// Normalize older editor overrides to the reference's single time/form display.
for(const card of cards){
 const body=card.querySelector('.assignment-body'),meta=body?.querySelector('.assignment-meta[data-task-meta]');if(!meta)continue;
 const time=meta.querySelector('.assignment-time');
 if(time){time.dataset.minutes=card.dataset.taskMinutes||time.dataset.minutes||'';time.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/></svg> ca. '+time.dataset.minutes+' Minuten';body.append(time);}
 meta.remove();
}

let active=null,interval=null,audio=null;const timers=new Map(),records=new Map();
const svg='<svg class="focus-net" viewBox="0 0 100 100" aria-hidden="true"><polygon points="50,8 90,37 75,85 25,85 10,37" fill="#f1f6fa" stroke="#526e83" stroke-width="2.6"/><polygon points="50,23 76,42 66,73 34,73 24,42" fill="none" stroke="#7e96a7" stroke-width="2"/><path d="M50 51L90 37M50 51L75 85M50 51L25 85M50 51L10 37" stroke="#6e879a" stroke-width="2.4"/><path d="M50 51L50 8" stroke="#0078a8" stroke-width="7" stroke-linecap="round"/><circle cx="50" cy="8" r="5" fill="#0078a8"/></svg>';
const clockSvg='<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/></svg>';
function element(tag,cls,text){const e=document.createElement(tag);if(cls)e.className=cls;if(text)e.textContent=text;return e;}
function button(text,fn){const b=element('button','',text);b.type='button';b.addEventListener('click',fn);return b;}
function separateTaskCommands(body){
 // Format the current, editor-adjusted DOM once for both views. Ranges retain
 // nested emphasis and links; lowercase/inline operators remain in their sentence.
 for(const paragraph of [...body.querySelectorAll('p')]){
  if(paragraph.closest('.assignment-note,.book-reference,.chronology,[data-assessment-widget],table'))continue;
  const starts=[...paragraph.querySelectorAll('strong')].filter(node=>
   (node.matches('.operator:not(.operator-inline)')&&/^[A-ZÄÖÜ]/.test(node.textContent.trim()))||
   /^(Zwischensicherung|Ergebnissicherung):$/.test(node.textContent.trim()));
  for(const start of starts.reverse()){
   const before=document.createRange();before.selectNodeContents(paragraph);before.setEndBefore(start);
   if(!before.toString().trim())continue;
   const tail=document.createRange();tail.selectNodeContents(paragraph);tail.setStartBefore(start);
   const next=paragraph.cloneNode(false);next.removeAttribute('id');next.append(tail.extractContents());paragraph.after(next);
  }
 }
}
function prepareAudio(){try{const K=window.AudioContext||window.webkitAudioContext;if(K){audio||=new K();if(audio.state==='suspended')audio.resume().catch(()=>{});}}catch{}}
function chime(r){if(!r.sound.checked||audio?.state!=='running')return;try{const now=audio.currentTime;[0,.38,.76].forEach(delay=>{[880,1320].forEach((frequency,i)=>{const o=audio.createOscillator(),g=audio.createGain();o.frequency.value=frequency;g.gain.setValueAtTime(0,now+delay);g.gain.linearRampToValueAtTime(i?.055:.11,now+delay+.015);g.gain.exponentialRampToValueAtTime(.001,now+delay+.32);o.connect(g);g.connect(audio.destination);o.start(now+delay);o.stop(now+delay+.34);});});}catch{}}
function timerState(total,key){const base={total,remaining:total,running:false,deadline:0,key};try{const saved=JSON.parse(sessionStorage.getItem(key)||'null');if(saved&&saved.total===total&&Number.isInteger(saved.remaining)&&saved.remaining>=0&&saved.remaining<=total)base.remaining=saved.remaining;}catch{}return base;}
function saveClock(t){try{sessionStorage.setItem(t.key,JSON.stringify({total:t.total,remaining:t.remaining}));}catch{}}
function draw(r){const t=timers.get(r.card);if(!t)return;const ratio=1-t.remaining/t.total,mix=ratio<=.5?ratio*2:(ratio-.5)*2,a=ratio<=.5?[175,202,11]:[17,17,17],b=ratio<=.5?[17,17,17]:[180,35,24];r.time.textContent=String(Math.floor(t.remaining/60)).padStart(2,'0')+':'+String(t.remaining%60).padStart(2,'0');r.time.style.color='rgb('+a.map((v,i)=>Math.round(v+(b[i]-v)*mix)).join(',')+')';r.pause.hidden=t.remaining===0;r.pause.textContent=t.running?'Pause':'Fortsetzen';r.alarm.hidden=t.remaining>0;r.timerNote.textContent=t.remaining?'Die Zeit ist eine Orientierung. Du kannst pausieren und nach Ablauf weiterarbeiten.':'Orientierungszeit erreicht. Du kannst weiterarbeiten.';}
function tick(r){const t=timers.get(r.card);if(!t?.running)return;const previous=t.remaining;t.remaining=Math.max(0,Math.ceil((t.deadline-Date.now())/1000));if(!t.remaining){t.running=false;if(previous>0)chime(r);}if(previous!==t.remaining)saveClock(t);draw(r);}
function pause(r){const t=timers.get(r.card);if(!t)return;tick(r);t.running=false;saveClock(t);draw(r);}
function start(r){const t=timers.get(r.card);if(!t||!t.remaining)return;t.deadline=Date.now()+t.remaining*1000;t.running=true;draw(r);}
function restore(){for(const r of records.values())r.card.append(r.completion);document.querySelectorAll('[data-focus-suppressed]').forEach(e=>{e.classList.remove('focus-suppressed');delete e.dataset.focusSuppressed;});document.body.classList.remove('task-focus');}
function suppress(e){e.dataset.focusSuppressed='';e.classList.add('focus-suppressed');}
function close(focusSummary=true){if(!active)return;const r=active;pause(r);active=null;clearInterval(interval);interval=null;r.details.open=false;restore();if(focusSummary)r.summary.focus();}
document.addEventListener('click',event=>{const link=event.target.closest?.('.task-focus-panel a[href="#kompetenzcheck"]');if(!link||!active)return;const target=document.getElementById('kompetenzcheck');if(!target)return;event.preventDefault();close(false);target.scrollIntoView({block:'start',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});});
function open(r){if(active===r)return;window.SOZ_MATERIAL_RETURN?.remember(r.card.dataset.taskId);close(false);active=r;refresh(r);r.details.open=true;r.card.querySelector('.focus-task-footer').insertBefore(r.completion,r.next);document.body.classList.add('task-focus');const content=document.querySelector('.lesson-content');for(const e of content.children){if(!e.contains(r.card)&&!e.matches('.material-access,.phase-materials,.material-actions-row'))suppress(e);}
 for(const c of cards)if(c!==r.card)suppress(c);
 document.querySelectorAll('.brand-header,.main>.navigation,.main>.tools-bar,.phase-mode-title').forEach(suppress);
 const panel=r.card.closest('[data-mode-panel]');if(panel)for(const child of panel.children)if(!child.contains(r.card)&&child!==r.card)suppress(child);
 draw(r);start(r);clearInterval(interval);interval=setInterval(()=>tick(r),200);r.card.querySelector('.task-focus-panel').focus({preventScroll:true});if(!matchMedia('(prefers-reduced-motion: reduce)').matches){const h=r.card.getBoundingClientRect().height;r.card.animate([{height:(r.beforeHeight||h)+'px',overflow:'hidden'},{height:h+'px',overflow:'hidden'}],{duration:350,easing:'ease-out'});r.card.querySelector('.task-focus-panel').animate([{opacity:0,transform:'translateY(12px)'},{opacity:1,transform:'translateY(0)'}],{duration:350,easing:'ease-out'});}const materialBar=document.querySelector('.lesson-content>.material-actions-row,.lesson-content>.material-access,.lesson-content>.phase-materials');if(materialBar)r.card.style.scrollMarginTop=(materialBar.getBoundingClientRect().height+10)+'px';r.card.scrollIntoView({block:'start',behavior:'smooth'});}
function nextRecord(r){const panel=r.card.closest('[data-mode-panel]');const list=cards.filter(c=>c.closest('[data-mode-panel]')===panel);return records.get(list[list.indexOf(r.card)+1]);}
function refresh(r){r.next.disabled=!r.checkbox?.checked||r.checkbox.disabled||P.readOnly;r.summary.classList.toggle('focus-task-done',!!r.checkbox?.checked);r.card.classList.toggle('focus-card-complete',!!r.checkbox?.checked);r.doneMarker.hidden=!r.checkbox?.checked;}
for(const card of cards){
 const body=card.querySelector('.assignment-body'),completion=card.querySelector('[data-completion-label]'),checkbox=completion?.querySelector('input');if(!body||!checkbox)continue;
 const number=card.querySelector('.assignment-number')||element('span','assignment-number',card.dataset.taskNumber||'');
 const originalTime=card.querySelector('.assignment-time');const match=originalTime?.textContent.match(/(\d+(?:[.,]\d+)?)\s*Min/i);const taskMinutes=Number(card.dataset.taskMinutes)||(match?Number(match[1].replace(',','.')):0);const seconds=taskMinutes>0?Math.round(taskMinutes*60):0;
 const details=element('details','task-accordion'),summary=element('summary','task-summary');const strip=element('span','focus-symbol-strip'),top=element('span','focus-symbol-top');top.append(number);const logo=card.querySelector('img.assignment-goodnotes');if(logo){const image=logo.cloneNode(true);image.classList.add('focus-goodnotes-logo');top.append(image);}strip.append(top);for(const icon of card.querySelectorAll('.assignment-kind,.assignment-social'))strip.append(icon);const phaseForm=card.closest('[data-mode-panel]')?.querySelectorAll('.phase-meta p')[1];if(phaseForm&&!strip.querySelector('.assignment-social')){const form=element('span','focus-phase-form');const icon=phaseForm.querySelector('svg');if(icon)form.append(icon.cloneNode(true));const formText=phaseForm.querySelector('span')?.textContent.replace(/^Arbeitsform:\s*/,'').trim();if(formText)form.append(element('span','',formText));strip.append(form);}summary.append(strip);
 const preview=element('span','task-preview',(body.querySelector('.assignment-command')||body.querySelector('p')||body).textContent.replace(/\s+/g,' ').trim().slice(0,140));
 const opener=element('span','task-open-label','Bearbeiten');
 const focus=element('div','task-focus-panel');focus.tabIndex=-1;focus.setAttribute('role','region');focus.setAttribute('aria-label','Aufgabenfokus');const competence=element('aside','focus-competence');const copy=element('div','focus-competence-copy');copy.append(element('strong','','Fachkompetenz'),element('p','',D.competencies.find(c=>c.label==='Fachkompetenz')?.statement||''));competence.append(copy);const net=element('span','focus-net-wrap');net.innerHTML=svg;competence.append(net);focus.append(competence);
 const tools=element('div','focus-toolbar'),back=button('Phasenübersicht',()=>close());tools.append(back);const headingRow=element('div','focus-task-heading');headingRow.append(competence,tools);focus.append(headingRow);
 separateTaskCommands(body);
 const originalPreview=body.cloneNode(true);originalPreview.className='task-original-preview';originalPreview.querySelectorAll('.chronology,[data-assessment-widget]').forEach(e=>e.remove());const doneMarker=element('span','task-done-check','✓');doneMarker.setAttribute('aria-label','Aufgabe erledigt');doneMarker.setAttribute('role','img');const r={card,details,summary,checkbox,completion,originalPreview,doneMarker,next:null,sound:null};
 if(seconds){const key=(window.SOZ_TEACHER_VIEW?.active?'teacher:':'')+'task-focus-clock:'+D.id+':'+location.pathname.replace(/[^/]+$/,'')+':'+card.dataset.taskId;timers.set(card,timerState(seconds,key));const timer=element('div','focus-timer'),row=element('div','focus-timer-row'),icon=element('span','focus-clock');icon.innerHTML=clockSvg;const time=element('span','focus-countdown');time.setAttribute('role','timer');time.setAttribute('aria-label','Verbleibende Orientierungszeit');const pauseButton=button('Pause',()=>{prepareAudio();timers.get(card).running?pause(r):start(r);});row.append(icon,time,pauseButton);const note=element('p','focus-timer-note');const soundLabel=element('label','focus-sound'),sound=element('input');sound.type='checkbox';sound.checked=true;sound.addEventListener('change',()=>{if(sound.checked)prepareAudio();});soundLabel.append(sound,document.createTextNode(' 🔔'));soundLabel.title='Signalton ein- oder ausschalten';sound.setAttribute('aria-label','Signalton bei Zeitablauf');const alarm=element('p','focus-alarm');alarm.setAttribute('role','status');const bell=element('span','focus-bell','🔔');bell.setAttribute('aria-hidden','true');alarm.append(bell,document.createTextNode(' Orientierungszeit erreicht'));alarm.hidden=true;row.append(soundLabel);timer.append(row,note,alarm);tools.append(timer);Object.assign(r,{time,pause:pauseButton,sound,timerNote:note,alarm});draw(r);}
 focus.append(body);
 const help=element('aside','focus-ai-help');
 const helpButton=button('KI-Hilfe öffnen',()=>{
 let dialog=document.querySelector('.ais-help-dialog');
 if(!dialog){dialog=element('dialog','ais-help-dialog');const heading=element('header','ais-help-heading');const title=element('strong','','KI-Hilfe · Löppt-Pilot');title.id='ais-help-title';dialog.setAttribute('aria-labelledby',title.id);heading.append(title,button('Schließen',()=>dialog.close()));const note=element('p','ais-help-note','Hilfe zur Selbsthilfe · Deine Lösung erarbeitest du selbst.');const iframe=element('iframe','ais-help-frame');iframe.title='AIS-Chat – KI-Hilfe zur Selbsthilfe';iframe.src=options.aiHelpByPhase?.[document.body.dataset.page]||options.aiHelpUrl;const info=element('p','ais-help-info','Falls der Chat leer bleibt oder die Anmeldung nicht funktioniert, ist die Einbettung möglicherweise durch AIS oder die Moodle-App eingeschränkt.');dialog.append(heading,note,iframe,info);document.body.append(dialog);}dialog.showModal();
 });const aiLogo=element('span','ais-chat-logo');aiLogo.innerHTML='<svg xmlns="http://www.w3.org/2000/svg" width="142" height="32" viewBox="0 0 142 32" role="img" aria-label="AIS.chat"><title>AIS.chat</title><g fill="none" stroke="#4e248c" stroke-width="3.3" stroke-linecap="round"><rect x="3" y="5" width="20" height="8" rx="4"/><path d="M16 18h7M22 22h2"/></g><text x="33" y="25" fill="#4e248c" font-family="Arial,Helvetica,sans-serif" font-size="23">AIS.chat</text></svg>';helpButton.prepend(aiLogo);helpButton.title='Hilfe zur Selbsthilfe';help.append(helpButton);focus.append(help);
 const solvedText=completion.querySelector('.sr-only');if(solvedText)solvedText.textContent='Aufgabe erledigt';const footer=element('div','focus-task-footer');const next=button('Zur nächsten Aufgabe →',()=>{if(!checkbox.checked||checkbox.disabled||P.readOnly)return;const n=nextRecord(r);if(n)open(n);else close();});next.className='focus-next';r.next=next;const backActions=element('div','focus-back-actions');backActions.append(back);footer.append(backActions,completion,next);focus.append(footer);details.append(summary,focus);card.replaceChildren(details,originalPreview,completion,doneMarker);records.set(card,r);originalPreview.addEventListener('click',event=>{if(!event.target.closest('a,button,input,textarea,select')){if(r.sound?.checked)prepareAudio();r.beforeHeight=card.getBoundingClientRect().height;open(r);}});
 summary.addEventListener('click',event=>{if(details.open){event.preventDefault();return;}r.beforeHeight=card.getBoundingClientRect().height;if(r.sound?.checked)prepareAudio();});details.addEventListener('toggle',()=>{if(details.open)open(r);else if(active===r)close();});checkbox.addEventListener('click',event=>event.stopPropagation());checkbox.addEventListener('change',event=>{event.stopPropagation();refresh(r);});refresh(r);
}
for(const r of records.values())if(!nextRecord(r))r.next.textContent='Zur Phasenübersicht →';
new MutationObserver(()=>close(false)).observe(document.body,{attributes:true,attributeFilter:['data-mode']});
window.addEventListener('pagehide',()=>{if(active)pause(active);clearInterval(interval);});document.addEventListener('keydown',event=>{if(event.key==='Escape'&&active){event.preventDefault();close();}});
window.addEventListener('beforeprint',()=>{close(false);for(const r of records.values())r.details.open=true;document.body.classList.add('focus-print');});window.addEventListener('afterprint',()=>{document.body.classList.remove('focus-print');for(const r of records.values())r.details.open=false;});
const requested=new URLSearchParams(location.search).get('aufgabe');if(requested){const r=[...records.values()].find(r=>r.card.dataset.taskId===requested);if(r)open(r);}
window.SOZ_TASK_FOCUS={close,refresh:()=>records.forEach(refresh)};window.SOZ_SCORM?.subscribe(()=>records.forEach(refresh));
document.body.dataset.taskFocusReady='true';
})(/* LS_TASK_FOCUS_OPTIONS */{"aiHelpUrl":"https://app.ais-chat.schule/ua/characters/2b7bdc3e-19fb-4b9d-baaf-4c17ad2b83d0/dialog?inviteCode=QLDYEBIV"});
/* End shared task focus UI. */
