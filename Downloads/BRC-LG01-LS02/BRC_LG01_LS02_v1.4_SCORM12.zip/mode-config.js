window.SOZ_CONFIG={"mode": 1, "allowStudentMode": false, "moodle": {}, "media": {}, "overrides": {}, "packageRevision": "BRC-LG01-LS02-BILDER-GRUPPEN-20261014", "pinHash": 1509442};
