window.SOZ_CONFIG={"mode":1,"allowStudentMode":false,"moodle":{},"media":{},"overrides":{},"packageRevision":"LG01-SozPaed-V2","pinHash":1509442,"packageVersion":"1.8.3","orientationVideoUrl":""};
