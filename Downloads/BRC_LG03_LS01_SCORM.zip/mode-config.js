window.SOZ_CONFIG={"mode": 1, "allowStudentMode": false, "moodle": {}, "media": {}, "overrides": {}, "packageRevision": "BRC-LG03-LS01-20261015-2", "pinHash": 1509442};
