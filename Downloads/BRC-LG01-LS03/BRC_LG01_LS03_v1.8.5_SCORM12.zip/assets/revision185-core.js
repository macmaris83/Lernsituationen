/* 1.8.5 compatibility: extend existing cores; never replace content signatures. */
(()=>{'use strict';
const K=window.SOZ_PROGRESS_CORE;if(!K||K.__form185)return;K.__form185=true;
const originalInitial=K.initial,originalSanitize=K.sanitize,originalBlocked=K.blockedBy,originalMetadata=K.metadataFrom;
K.initial=function(meta,mode){return {qf:{},qn:{},qh:{},...originalInitial(meta,mode)};};
K.sanitize=function(raw,meta,mode){const p=originalSanitize(raw,meta,mode);p.qf||={};p.qn||={};p.qh||={};if(raw?.s===1&&raw.l===meta.id){if(raw.o===true&&(meta.legacyOrientationSignatures||[]).includes(raw.w)&&K.orientationVideoCanContinue(p,meta))p.o=true;if(raw.v===meta.quizSignature)for(const q of meta.quiz||[]){const first=raw.qf?.[q.id];if(typeof first==='boolean'||first===null)p.qf[q.id]=first;else if(!raw.qf&&p.q[q.id])p.qf[q.id]=null;const n=raw.qn?.[q.id];if(Number.isInteger(n)&&n>0)p.qn[q.id]=Math.min(n,1000000);if(raw.qh?.[q.id]===true)p.qh[q.id]=true;}}return p;};
K.metadataFrom=function(data,parser){const meta=originalMetadata(data,parser);meta.legacyOrientationSignatures=[...new Set([...(meta.legacyOrientationSignatures||[]),...(data.form185LegacyOrientationSignatures||[])])];return meta;};
K.blockedBy=function(p,meta,page,mode=p.m){if(window.SOZ_TEACHER_VIEW?.active)return null;if(page==='handlungssituation.html')return p.o?null:'index';if(K.phases.includes(page.replace('.html',''))&&!p.o)return 'index';return originalBlocked(p,meta,page,mode);};
K.orientationVideoCanContinue||=()=>true;
K.orientationVideoComplete||=()=>true;
K.flashcardComplete||=((p,meta)=>!meta.flashcard||p.fc?.complete===true);
K.flashcardValid||=((p,meta)=>!!meta.flashcard&&p.fc?.id===meta.id&&p.fc?.signature===meta.flashcard.signature);
K.sharePoints||=((budget,count,index)=>{if(!count||index<0||index>=count)return 0;const units=Math.round(budget*100);return (Math.floor(units/count)+(index<units%count?1:0))/100;});
K.taskPoints||=((meta,id,mode=1)=>{const ids=Object.keys(meta.tasks||{}).filter(k=>meta.tasks[k].mode===Number(mode));return K.sharePoints(25,ids.length,ids.indexOf(id));});
K.situationValue||=((p,meta,id)=>Math.round(K.sharePoints(15,meta.quiz.length,meta.quiz.findIndex(q=>q.id===id))*((p.qh?.[id]||p.qf?.[id]===false)?0.6:1)*100)/100);
// Masters without a term test keep their existing tasks and HS check (40 XP).
// No artificial term content or automatic extra credit is introduced.
K.grading||=function(p,meta){const tasks=Object.entries(meta.tasks).filter(([,t])=>t.mode===Number(p.m));const taskPoints=tasks.reduce((s,[id,t])=>s+(p.t[id]===t.signature?K.taskPoints(meta,id,p.m):0),0),situationPoints=meta.quiz.reduce((s,q)=>s+(p.v===meta.quizSignature&&p.q[q.id]?.[1]&&p.q[q.id][0]===q.correct?K.situationValue(p,meta,q.id):0),0),round=n=>Math.round(n*100)/100;return {points:round(taskPoints+situationPoints),taskPoints:round(taskPoints),situationPoints:round(situationPoints),termPoints:0,termsTotal:0,termsCorrect:0,tasksDone:tasks.filter(([id,t])=>p.t[id]===t.signature).length,tasksTotal:tasks.length,maxPoints:40,ready:K.allComplete(p,meta)};};
})();

/* Shared XP UI from IDN. */



(() => {
  'use strict';
  const format = n => Number(n || 0).toLocaleString('de-DE', {maximumFractionDigits: 2});
  const tier = n => n >= 90 ? 'gold' : n >= 75 ? 'silver' : n >= 50 ? 'bronze' : 'dark';
  const tierName = n => n >= 90 ? 'Gold' : n >= 75 ? 'Silber' : n >= 50 ? 'Bronze' : 'Start';
  const reduced = () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  const icon = '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="9"/><path d="m12 6 1.8 3.6 4 .6-2.9 2.8.7 4-3.6-1.9L8.4 17l.7-4-2.9-2.8 4-.6Z"/></svg>';
  function markup(points, earned = false, title = '') {
    const safeTitle = String(title).replace(/[&"<>]/g, c => ({'&':'&amp;','"':'&quot;','<':'&lt;','>':'&gt;'}[c]));
    return '<span class="point-badge' + (earned ? ' point-earned' : '') + '" title="' + safeTitle + '">' + icon + '<span>' + (earned ? '' : '+') + format(points) + ' XP</span></span>';
  }
  function badge(points, earned, title) {
    const template = document.createElement('template');
    template.innerHTML = markup(points, earned, title);
    return template.content.firstElementChild;
  }
  function award(anchor, points) {
    if (!anchor || !points) return;
    document.querySelectorAll('.point-reward').forEach(el => el.remove());
    const popup = document.createElement('span');
    popup.className = 'point-reward';
    popup.textContent = '+' + format(points) + ' XP';
    popup.setAttribute('role', 'status');
    const rect = anchor.getBoundingClientRect();
    popup.style.left = Math.max(8, Math.min(innerWidth - 150, rect.left)) + 'px';
    popup.style.top = Math.max(10, Math.min(innerHeight - 44, rect.top - 30)) + 'px';
    document.body.append(popup);
    setTimeout(() => popup.remove(), reduced() ? 1600 : 1250);
  }
  let positionObserver = null;
  function mount() {
    // The score belongs to the visible lesson, in its footer.
    // The SCORM host keeps only the persistent unfinished-test reminder.
    if (document.querySelector('[data-scorm-frame]')) return null;
    const page = document.body.dataset.page || '';
    if (document.body.dataset.teacher || page === 'druckansicht.html') return null;
    const focus = document.body.classList.contains('task-focus')
      ? document.querySelector('.task-accordion[open] .task-focus-panel') : null;
    const navigation = /^m\d+\.html$/.test(page) ? document.querySelector('.material-phase-navigation') : document.querySelector('.navigation, .b-phase-overview');
    const target = document.querySelector('.page-footer,.b-footer') || navigation;
    if (!target) return null;
    let row = document.querySelector('[data-phase-points]');
    if (!row) {
      row = document.createElement('div');
      row.className = 'phase-points-row no-print';
      row.dataset.phasePoints = '';
    }
    if (row.parentElement !== target) target.prepend(row);
    let el = row.querySelector('[data-point-float]');
    if (!el) {
      el = document.createElement('aside');
      el.className = 'point-float no-print';
      el.dataset.pointFloat = '';
      el.innerHTML = '<div class="points-battery" role="progressbar" aria-label="Aktueller SCORM-Punktestand" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><span class="points-battery-track"><span class="points-battery-fill"></span></span><strong class="points-battery-label">0 / 100 XP</strong></div><span class="points-live sr-only" aria-live="polite" aria-atomic="true"></span>';
      row.append(el);
    }
    if (!positionObserver && window.MutationObserver) {
      positionObserver = new MutationObserver(() => mount());
      positionObserver.observe(document.body, {attributes:true, attributeFilter:['class']});
    }
    return el;
  }
  function render(grade, animate = true) {
    const el = mount();
    if (!el) return;
    const maximum=grade.maxPoints||100;const points = Math.max(0, Math.min(maximum, Number(grade.points) || 0));
    const last = el.dataset.points === undefined ? null : Number(el.dataset.points);
    const track = el.querySelector('.points-battery');
    el.dataset.points = String(points);
    el.dataset.tier = tier(points/maximum*100);
    track.setAttribute('aria-valuemax',String(maximum));track.setAttribute('aria-valuenow', String(points));
    track.setAttribute('aria-valuetext', format(points) + ' von '+maximum+' XP; ' + tierName(points/maximum*100));
    el.querySelector('.points-battery-fill').style.width = (points/maximum*100) + '%';
    el.querySelector('.points-battery-label').textContent = format(points) + ' / '+maximum+' XP';
    el.title = 'XP aus dem gespeicherten Lernstand: '+format(points)+' / '+maximum;
    if (animate && last !== null && points > last) {
      el.querySelector('.points-live').textContent = '+' + format(points - last) + ' XP. Jetzt ' + format(points) + ' von '+maximum+' XP.';
      if (!reduced() && el.animate) el.animate([{transform:'scale(1)'},{transform:'scale(1.04)'},{transform:'scale(1)'}], {duration:420});
    }
  }
  window.SOZ_POINTS_UI = {format, tier, markup, badge, award, render};
})();
