# Quellenzuordnung · LS 3.2: Lebenswelten analysieren

Ausgangspaket: `SozPaed_LS3_2_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Lebenswelt** – m2.html; Jana, Leon und Aylin beschreiben unterschiedliche Möglichkeiten und Wünsche im freiwilligen Treff.

2. **Lebensweltorientierung** – m2.html; Rieke richtet Zugänge an den konkret geäußerten Wünschen der Jugendlichen aus.

3. **Sozialraumorientierung** – m3.html; Die Übersicht des Treffs betrachtet dokumentierte Orte und Kontaktwege, nicht eine erfundene Karte aller Jugendlichen.

4. **Zähleinheit** – m1.html; Die Wochenliste zählt Tagesbesuche; wiederholte Besuche können von derselben Person stammen.

5. **Repräsentativität** – m2.html; Janas Aussage und die Besuchsübersicht stehen nicht automatisch für alle Jugendlichen des Viertels.

6. **Zugangsbarriere** – handlungssituation.html; Leon erfährt manches erst, wenn ein Termin oder eine Entscheidung schon vorbei ist.

7. **Beteiligung** – m2.html; Jana möchte Raum und Ablauf mitbestimmen und nicht lediglich beim Aufbau helfen.

8. **Digitale Beteiligung** – m4.html; Aylin möchte vorab eine Projektidee schicken und später erfahren, was daraus wurde.

9. **Datensparsamkeit** – m2.html; Aylin gibt ihre Projektidee frei, nicht den übrigen privaten Nachrichtenverlauf.

10. **Informationslücke** – m1.html; Die Zahl unterschiedlicher Personen über die Woche wurde nicht erfasst.

11. **Transparenz** – m2.html; Eine Zusammenfassung soll Leon zeigen, welche Fragen noch offen sind und wo Einfluss möglich ist.

12. **Evaluation** – m4.html; Die Prüfung fragt nach tatsächlichem Einfluss verschiedener Zugänge statt nur nach Besuchszahlen.

