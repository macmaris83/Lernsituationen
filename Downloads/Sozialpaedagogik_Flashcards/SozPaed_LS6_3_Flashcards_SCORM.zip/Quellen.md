# Quellenzuordnung · LS 6.3: Vorurteile reflektieren

Ausgangspaket: `SozPaed_LS6_3_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Stereotyp** – m1.html; Aus der Abwesenheit beim Familientermin entsteht die pauschale Aussage über angeblich uninteressierte Eltern.

2. **Vorurteil** – handlungssituation.html; Die Bewertung wird getroffen, obwohl Gründe des Fehlens nicht erfragt wurden.

3. **Diskriminierung** – m3.html; Nur zuvor anwesende Familien persönlich anzusprechen kann ungleiche Beteiligungschancen weiter verstärken.

4. **Beobachtung** – m2.html; Dokumentiert ist die Nichtteilnahme, nicht ein fehlendes Interesse der Familien.

5. **Hypothese** – m4.html; Eine Erklärung für das Fehlen muss überprüft werden, bevor sie eine Einladungsentscheidung bestimmt.

6. **Selbsterfüllende Erwartung** – m3.html; Eine negative Erwartung führt zu weniger persönlicher Ansprache; erneutes Fernbleiben könnte dann als Bestätigung erscheinen.

7. **Chancengerechtigkeit** – m4.html; Das Team prüft, welche Ansprache auch bisher nicht erreichte Familien tatsächlich zugänglich macht.

8. **Perspektivwechsel** – m2.html; Die Entscheidung wird aus Sicht einer Familie betrachtet, die bislang nur den Aushang erhalten hat.

9. **Pädagogischer Auftrag** – handlungssituation.html; Die Reflexion prüft konkrete Einladungsentscheidungen, statt Kolleginnen und Kollegen pauschal abzuwerten.

10. **Quellenprüfung** – m4.html; Wortlaut, Gesprächskontext und tatsächliche Informationsbasis der Aussage werden getrennt dokumentiert.

11. **Vergleichbarkeit** – m3.html; Die geschlechtsbezogene Auswahl im Treff dient als eigener Vergleichsfall und wird nicht mit den Familien gleichgesetzt.

12. **Reflexion** – m4.html; Das Team verbindet seine Annahme mit der daraus entstandenen Auswahl und prüft deren Folgen.

