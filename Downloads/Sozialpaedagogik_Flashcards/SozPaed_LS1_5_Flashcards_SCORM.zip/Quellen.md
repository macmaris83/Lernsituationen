# Quellenzuordnung · LS 1.5: Bildungsprozesse gestalten

Ausgangspaket: `SozPaed_LS1_5_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Bildung** – m3.html; Beim Bauen verändern Kinder ihre Ideen und erschließen Zusammenhänge, auch wenn kein fertiges Werk entsteht.

2. **Selbstbildung** – m3.html; Theo verändert nach dem Herunterfallen eines Steins die Anordnung und versucht es erneut.

3. **Bildungsimpuls** – m4.html; Ein Einstieg kann Kinder zum Weiterdenken anregen, ohne das fertige Bauwerk aller festzulegen.

4. **Eigenaktivität** – m3.html; Fabian arbeitet an seiner Burg weiter; Martha zeigt aus dem Buch zur Bauecke.

5. **Lernumgebung** – m3.html; Steine, Bildimpulse, freie Flächen und der zugleich genutzte Gestaltungstisch beeinflussen den Zugang.

6. **Prozessorientierung** – m1.html; Der Aushang zeigt fertige Bauwerke, aber keine Kinderfragen oder Veränderungen während des Bauens.

7. **Beteiligung** – m2.html; Beim Vergleich der Vorschläge wird geprüft, welche Entscheidungen die Kinder selbst treffen können.

8. **Ressourcenrahmen** – m4.html; Der Bauimpuls muss mit vorhandenem Material und ohne zusätzliche Fachkraft funktionieren.

9. **Zuständigkeit** – m4.html; Die Praxisgruppe darf vorbereiten und vereinbarte Teile begleiten; die Verantwortung bleibt abgesprochen.

10. **Dokumentation** – m1.html; Kurze Verlaufsnotizen und beschriftete Skizzen können sichtbar machen, wie eine Idee verändert wurde.

11. **Datensparsamkeit** – m1.html; Ohne neue Einwilligungen nutzt das Team zunächst anonyme Skizzen statt personenbezogener Außenfotos.

12. **Evaluation** – m4.html; Beide Impulsvorschläge werden darauf geprüft, welche Lernprozesse beobachtet und später erklärt werden könnten.

