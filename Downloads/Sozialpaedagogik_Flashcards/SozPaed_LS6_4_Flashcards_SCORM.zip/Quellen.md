# Quellenzuordnung · LS 6.4: Chancengerechtigkeit fördern

Ausgangspaket: `SozPaed_LS6_4_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Chancengerechtigkeit** – m3.html; Der Zugang wird so geprüft, dass auch unterschiedliche Termin- und Kontaktmöglichkeiten berücksichtigt werden.

2. **Zähleinheit** – m1.html; Zusagen, Veranstaltungsteilnahmen und spontan Hinzugekommene sind verschiedene Angaben.

3. **Beteiligungsquote** – m1.html; Für eine Quote muss geklärt sein, welche Teilnehmenden zu welcher Bezugsgruppe gehören.

4. **Beobachtung** – handlungssituation.html; Zehn Zusagen stehen acht Teilnahmen gegenüber; zwei Teilnehmende kamen spontan hinzu.

5. **Befund und Vermutung** – m4.html; Die Liste belegt Teilnahme, aber keine ungeprüften Erklärungen über Herkunft oder Desinteresse.

6. **Digitale Beteiligung** – m3.html; Aylins übermittelte Ideen erscheinen nicht automatisch in einer Anwesenheitszahl.

7. **Zugangsbarriere** – m3.html; Leon stellt die feste Terminwahl infrage und braucht eine passende Möglichkeit der Rückmeldung.

8. **Beteiligung** – m3.html; Jana möchte vor der Festlegung Einfluss auf die Planung haben.

9. **Ressourcenrahmen** – handlungssituation.html; Einladung und Ablauf können verändert werden; zusätzliche Personalstunden stehen nicht bereit.

10. **Vergleichbarkeit** – m2.html; Die Bremer Unterlage hat andere Zähleinheiten und Bedingungen und muss entsprechend eingeordnet werden.

11. **Informationslücke** – handlungssituation.html; Herkunft und Lebenslage wurden nicht erhoben; damit lassen sich keine gruppenbezogenen Ursachen belegen.

12. **Evaluation** – m4.html; Die Auswertung betrachtet Erreichbarkeit und Einfluss der Beiträge statt bloß die Differenz zweier Gesamtzahlen.

