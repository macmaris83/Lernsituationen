# Quellenzuordnung · LS 6.2: Barrieren abbauen

Ausgangspaket: `SozPaed_LS6_2_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Zugangsbarriere** – handlungssituation.html; Die Bildkarte war vom Eingang aus nicht erkennbar; das könnte den Einstieg erschweren.

2. **Barrierefreiheit** – m3.html; Material, Hinweise und Begleitung werden darauf geprüft, ob unterschiedliche Kinder sie nutzen können.

3. **Teilhabe** – m1.html; Bei der Bauwerkstatt wird nicht nur gefragt, wer im Raum war, sondern welche Handlungsmöglichkeiten bestanden.

4. **Anwesenheit und Teilhabe** – m1.html; Zuschauen oder spätes Ankommen belegt nicht, ob ein Kind den Einstieg selbst wählen konnte.

5. **Beobachtung** – handlungssituation.html; Ein Kind bleibt am Eingang, ein anderes stellt eine Kiste zurück und sieht zu.

6. **Hypothese** – m4.html; „Sie wollten etwas anderes“ ist eine mögliche Erklärung, aber die Gründe wurden nicht verlässlich erfragt.

7. **Raumkonzept** – m3.html; Ein Umräumen wird auf Materialzugang, bestehende Tätigkeiten und Begleitung geprüft.

8. **Ressourcenrahmen** – handlungssituation.html; Tisch, Gruppenraum und Betreuung müssen auch für andere Tätigkeiten nutzbar bleiben.

9. **Beteiligung** – m4.html; Die Kinderperspektive soll geklärt werden, statt vom Zuschauverhalten allein auf Wünsche zu schließen.

10. **Vergleichbarkeit** – m2.html; Walle und Bremen liefern andere Einrichtungsausschnitte, keine weiteren Beobachtungen zur Auricher Werkstatt.

11. **Informationslücke** – handlungssituation.html; Genaue Raummaße und verlässliche Gründe des Zuschauens fehlen in den Unterlagen.

12. **Evaluation** – m4.html; Eine Veränderung wird daran geprüft, ob der Zugang tatsächlich verständlicher und nutzbarer geworden wäre.

