# Quellenzuordnung · LS 7.1: Berufsidentität reflektieren

Ausgangspaket: `SozPaed_LS7_1_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Professionelles Selbstverständnis** – m4.html; Eine Aussage über gute pädagogische Arbeit wird an einer eigenen Entscheidung erläutert.

2. **Berufsrolle** – m1.html; Emilia bringt ihre Sicht als FSJ-Kraft ein und klärt, welche Verantwortung sie selbst übernehmen kann.

3. **Wertorientierung** – m1.html; Emilia legt Wert auf Zuhören; Benedikt betont Verlässlichkeit im Team.

4. **Rollenkonflikt** – m1.html; Hamide betrachtet gerechte Regeln aus ihrer Leitungsrolle und zugleich als Mutter von Justus.

5. **Kompetenzbeleg** – m3.html; Eine genaue eigene Stelle stützt die berufliche Aussage, nicht nur eine überzeugend klingende Formulierung.

6. **Eigenanteil** – m3.html; In der Gruppenplanung ist Emilias fachlicher Beitrag noch nicht auffindbar.

7. **Pädagogische Handlungskompetenz** – m2.html; Zuhören wird mit begründeter Aufgabenabstimmung verbunden statt gegen sie ausgespielt.

8. **Zuständigkeit** – m2.html; Eine andere Aufgabe ist nicht automatisch übernommen, nur weil Emilia bei Leyla bleibt.

9. **Entwicklungsziel** – m4.html; Aus der Rückmeldung wird ein konkreter nächster Abstimmungsschritt abgeleitet.

10. **Reichweite eines Belegs** – m2.html; Ein beruflicher Vorsatz beschreibt nicht automatisch bereits nachgewiesenes Handeln.

11. **Informationslücke** – m2.html; Der spätere Verlauf nach Anastasias Rückmeldung wurde nicht protokolliert.

12. **Reflexion** – m2.html; Emilia vergleicht ihren ersten Vorsatz mit der tatsächlich beschriebenen Übergabe.

