# Quellenzuordnung · LS 5.3: Teilhabe gestalten

Ausgangspaket: `SozPaed_LS5_3_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Teilhabe** – m3.html; Jana, Leon und Aylin sollen trotz unterschiedlicher Anwesenheit Einfluss auf dasselbe Projekt haben können.

2. **Lebensweltorientierung** – handlungssituation.html; Der Entwurf knüpft an die geäußerten Wünsche der drei Jugendlichen an statt ein Berufsthema ungefragt festzulegen.

3. **Entscheidungsspielraum** – m3.html; Jana möchte wissen, was die Jugendlichen selbst entscheiden dürfen.

4. **Zähleinheit** – m1.html; Die 68 Tagesbesuche der Modellwoche sind keine 68 verschiedenen Personen.

5. **Zugangsbarriere** – m2.html; Eine einzige Entscheidungsrunde würde Beiträge ausschließen, die nicht gleichzeitig im Raum hörbar sind.

6. **Digitale Beteiligung** – m5.html; Aylins Vorabidee braucht einen Empfänger, einen Platz in der Themenliste und eine Rückmeldung.

7. **Konzeptbaustein** – m4.html; Ziel, Zugänge, Rollen und spätere Prüfung werden zu einem zusammenhängenden Entwurf verbunden.

8. **Ressourcenrahmen** – m4.html; Zwei Termine, höchstens 80 Euro Material und vier Stunden Vorbereitung/Auswertung sind die benannten Möglichkeiten.

9. **Rückmeldeweg** – m5.html; Leon braucht früh Termininformation; Aylin möchte wissen, wo ihr Vorschlag aufgegriffen wurde.

10. **Transparenz** – m5.html; „Wir haben entschieden“ reicht nicht, wenn unklar bleibt, wer entschieden und welche Beiträge berücksichtigt hat.

11. **Repräsentativität** – m1.html; Die drei bekannten Stimmen werden nicht als Aussage aller Jugendlichen im Viertel ausgegeben.

12. **Evaluation** – m5.html; Das Team prüft den Einfluss der Beiträge statt nur eine Anwesenheitsliste auszuwerten.

