# Quellenzuordnung · LS 4.1: Erklärungsmodelle vergleichen

Ausgangspaket: `SozPaed_LS4_1_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Psychoanalytische Perspektive** – m2.html; Eine Teamnotiz vermutet bei Emilia eine Spannung zwischen Anerkennung und Grenzen; das bleibt eine unbestätigte Erklärung.

2. **Lerntheoretische Perspektive** – m2.html; Eine andere Notiz fragt, ob Emilia frühere negative Folgen von Nachfragen erlebt hat; solche Verläufe sind nicht dokumentiert.

3. **Humanistische Perspektive** – m2.html; Die dritte Notiz fragt, wie die Übergabesituation zu Emilias eigenen Vorstellungen von sich passt.

4. **Selbstkonzept** – m3.html; Emilia soll ihre eigene Sicht erklären, statt dass das Team ihr ein festes Selbstbild zuschreibt.

5. **Verstärkung** – m2.html; Für eine Erklärung über Rückmeldungsfolgen müsste geprüft werden, welche Folgen welches Verhalten tatsächlich hatte.

6. **Lernen am Modell** – m4.html; Eine solche Erklärung müsste klären, welche beobachteten Vorbilder und Verhaltensfolgen für Emilia belegt sind.

7. **Hypothese** – m2.html; Die drei Randnotizen werden als mögliche Erklärungen geführt, nicht als festgestellte Ursachen.

8. **Menschenbild** – informieren; Beim fachlichen Vergleich wird gefragt, welche Annahmen über Menschen hinter den drei Perspektiven stehen.

9. **Pädagogischer Auftrag** – m2.html; Das nächste Gespräch klärt eine Teamabsprache; das Team hat keinen therapeutischen Auftrag.

10. **Modellgrenze** – m4.html; Dass eine Erklärung plausibel klingt, beweist nicht, weshalb Emilia die Rückmeldung so verstanden hat.

11. **Quellenprüfung** – m2.html; Die pauschale Notiz „kann Kritik nicht annehmen“ hat keine angegebene Grundlage.

12. **Perspektivwechsel** – handlungssituation.html; Theresa legt Emilias eigene Worte neben die Fremddeutungen des Teams.

