# Quellenzuordnung · LS 7.2: Teamkommunikation gestalten

Ausgangspaket: `SozPaed_LS7_2_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Aktives Zuhören** – m2.html; Anastasia könnte Emilias Anliegen in eigenen Worten wiedergeben und nachfragen, ob sie es richtig verstanden hat.

2. **Ich-Botschaft** – m1.html; Anastasia beschreibt ihre fehlende Information zur Aufgabe, statt Emilia pauschal als unprofessionell zu bewerten.

3. **Konkretes Feedback** – m1.html; Die Rückmeldung benennt die nicht abgesprochene Übergabe und klärt ein nächstes Handeln.

4. **Perspektivwechsel** – handlungssituation.html; Emilia hört eine Kritik am Zuhören; Anastasia meint die fehlende Aufgabenabstimmung.

5. **Informationslücke** – m1.html; Was geschieht, wenn niemand übernehmen kann, ist im bisherigen Gespräch noch nicht konkret geklärt.

6. **Gesprächsleitfaden** – m2.html; Anlass, beide Sichtweisen, offene Frage und eine umsetzbare Vereinbarung erhalten Platz im Gespräch.

7. **Übergabe** – m2.html; Eine neue Absprache klärt ausdrücklich, ob und von wem eine Aufgabe übernommen wurde.

8. **Zuständigkeit** – m4.html; Hamide ist Leitung, sitzt aber nicht automatisch im vorgesehenen Zweiergespräch.

9. **Multiprofessionelle Zusammenarbeit** – m3.html; Frühere Fallberatungen zu Paula und Noah verdeutlichen, dass verschiedene Rollen unterschiedliche Beiträge haben.

10. **Ressourcenrahmen** – m4.html; Eine Vereinbarung darf keine zusätzliche freie Person voraussetzen, die nicht zugesagt ist.

11. **Verlässlichkeit** – m2.html; Die Beteiligten vereinbaren, wie sie eine noch offene Übernahme rechtzeitig mitteilen.

12. **Evaluation** – m4.html; Die Rollenprobe prüft nicht nur den freundlichen Ton, sondern auch, ob die Handlungsfrage beantwortet wurde.

