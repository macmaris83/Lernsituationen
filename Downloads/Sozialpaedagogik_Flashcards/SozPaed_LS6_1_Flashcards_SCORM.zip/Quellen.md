# Quellenzuordnung · LS 6.1: Lebenslagen analysieren

Ausgangspaket: `SozPaed_LS6_1_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Lebenslage** – m1.html; Die Fachtagsredaktion betrachtet belegte Lebensbedingungen statt nur eine griffige Personenüberschrift.

2. **Diversität** – m1.html; Emilia, Theo, Tom und Aylin werden nicht auf jeweils ein Merkmal reduziert.

3. **Intersektionalität** – m2.html; Mehrere dokumentierte Bedingungen werden in ihrem Zusammenhang betrachtet; fehlende Angaben werden nicht ergänzt.

4. **Etikettierung** – m2.html; „Nur eine unsichere Anfängerin“ verdeckt Emilias Lerninteresse und ihre fachlichen Rückfragen.

5. **Stereotyp** – m1.html; Die Überschrift „der Junge aus der Wohngruppe“ kann eine pauschale Vorstellung auslösen, die Toms Akte nicht trägt.

6. **Ressourcenorientierung** – m2.html; Aylins Projektbeiträge werden neben der knappen Bezeichnung „nur digital dabei“ sichtbar gemacht.

7. **Datensparsamkeit** – m3.html; In die kurze Präsentationskarte gehören nur für den Fachtagszweck begründete Angaben.

8. **Transparenz** – m3.html; Quellen, Erläuterungen und offene Fragen können in der digitalen Begleitmappe ausgewiesen werden.

9. **Ressourcenrahmen** – m3.html; Für jede der vier Präsentationskarten stehen höchstens 90 Wörter zur Verfügung.

10. **Informationslücke** – m3.html; Toms eigene Sicht fehlt; die Redaktion erfindet sie nicht, damit die Karte voller aussieht.

11. **Quellenprüfung** – m4.html; Jede veröffentlichte Aussage wird mit einer Fundstelle in der Redaktionsmappe verbunden.

12. **Perspektivwechsel** – m4.html; Beim Lesetest wird gefragt, welches weitergehende Bild ein Kurztext beim Publikum auslöst.

