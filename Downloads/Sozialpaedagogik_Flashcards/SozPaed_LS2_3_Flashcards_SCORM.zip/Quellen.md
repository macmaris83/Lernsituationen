# Quellenzuordnung · LS 2.3: Bildungsangebote planen

Ausgangspaket: `SozPaed_LS2_3_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Spiel** – handlungssituation.html; Fabian baut seine eingestürzte Burg weiter und verändert dabei die Unterlage.

2. **Konstruktives Lernen** – handlungssituation.html; Gülcan fragt, ob auch ein anderer Gegenstand untergehen würde, und entwickelt eine eigene Prüfidee.

3. **Bildungsimpuls** – m2.html; Die Anregung soll Marthas, Gülcans oder Fabians Fragen aufgreifen statt nur ein gleiches Bastelergebnis erzeugen.

4. **Beobachtung** – m1.html; Martha betrachtet Oberflächen im Buch und setzt ihre Suche anschließend im Raum fort.

5. **Spielraum** – handlungssituation.html; Die laufende Burg darf nicht ohne Prüfung entfernt werden, nur um Platz für ein neues Angebot zu schaffen.

6. **Spielzeit** – m4.html; Am nächsten Vormittag ist ein begleiteter Angebotsplatz frei; bestehende Tätigkeiten laufen weiter.

7. **Erziehungsziel** – m3.html; Für einen Entwurf wird geklärt, welche Erkundung oder Fähigkeit das Angebot ermöglichen soll.

8. **Beteiligung** – m2.html; Kinder können eigene Fragen und Materialentscheidungen einbringen, statt jeden Schritt nachzumachen.

9. **Ressourcenrahmen** – m4.html; Beide Vorschläge müssen zu den vorhandenen Räumen, Materialien und Begleitmöglichkeiten passen.

10. **Abwägung** – m2.html; Die schöne Bastelidee wird mit einer stärker an den dokumentierten Interessen orientierten Idee verglichen.

11. **Ergebniskriterium** – m3.html; Die Planung benennt eine beobachtbare Erkundung statt allein ein vorzeigbares Endprodukt.

12. **Evaluation** – m3.html; Nach dem Angebot soll geprüft werden, welche Kinderfragen aufgegriffen und welche Zugänge möglich wurden.

