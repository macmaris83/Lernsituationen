# Quellenzuordnung · LS 4.5: Hilfesysteme erschließen

Ausgangspaket: `SozPaed_LS4_5_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Netzwerkplan** – m1.html; Die bisherige Liste nennt Stellen, aber häufig weder Kontaktzweck noch einen verständlichen ersten Schritt.

2. **Zielgruppe** – m4.html; Vor einer Empfehlung müssen Altersbereich und angesprochene Personengruppe des Angebots geprüft werden.

3. **Zugangsweg** – m1.html; Für eine Fachstelle fehlen in der Liste noch Anmeldung und Voraussetzungen des ersten Kontakts.

4. **Pädagogischer Auftrag** – handlungssituation.html; Das Team gibt Orientierung und stellt selbst keine Diagnose oder Aufnahmeentscheidung aus.

5. **Informationslücke** – m1.html; Das eigene Anliegen, Alter und die bisherige Unterstützung der ratsuchenden Person sind noch nicht konkret geklärt.

6. **Primärquelle** – m4.html; Aktuelle Angebote werden auf den offiziellen Seiten des Landkreises oder der 116117 geprüft.

7. **Gemeindenahe Versorgung** – m3.html; Der historische Bericht regt dazu an, erreichbare Unterstützung im Lebensumfeld miteinander zu verbinden.

8. **Psychiatrie-Enquête** – m3.html; Der Bericht von 1975 liefert historische Versorgungsforderungen, keine heutigen Öffnungszeiten oder freien Termine.

9. **Multiprofessionelle Zusammenarbeit** – handlungssituation.html; Ein Netzwerk verbindet unterschiedliche Beiträge, statt dieselbe unpräzise Anfrage einfach an viele Stellen zu schicken.

10. **Quellenprüfung** – m4.html; Name, Auftrag, örtlicher Bereich und Abrufdatum werden im Angebotsblatt nachvollziehbar festgehalten.

11. **Verlässlichkeit** – m2.html; Ein baldiger Termin darf nicht versprochen werden, wenn kein aktueller Zugang bestätigt wurde.

12. **Transparenz** – m2.html; Ratsuchende sollen zurückerklären können, weshalb eine Stelle infrage kommt und was der erste Schritt wäre.

