# Quellenzuordnung · LS 5.2: Beteiligung planen

Ausgangspaket: `SozPaed_LS5_2_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Hilfeplanung** – m4.html; Das Gespräch prüft Noahs bestehende Hilfe und verbindet seine Anliegen mit Zielen und nächsten Schritten.

2. **Hilfe zur Erziehung** – m1.html; Noahs Modellakte nennt § 27 in Verbindung mit § 34 SGB VIII; ein Wechsel der Hilfeart ist nicht beschlossen.

3. **Betreute Wohnform** – m1.html; Noah lebt seit einigen Monaten in der Wohngruppe Treffpunkt 16, die seinen Alltag pädagogisch begleitet.

4. **Beteiligung** – m3.html; Noah möchte mit seinen Fragen beginnen, bevor neue Regeln festgelegt werden.

5. **Scheinbeteiligung** – m5.html; Der Erwachsenenentwurf sieht Noahs Zustimmung erst nach den fertigen Regelvorschlägen vor.

6. **Selbstständigkeit** – m1.html; Noah möchte Rückwege selbst planen und einen eigenen Geldüberblick nutzen.

7. **Zuständigkeit** – m5.html; Im Ergebnisblatt muss stehen, welche Rolle welchen nächsten Unterstützungsschritt übernimmt.

8. **Handlungsplan** – m5.html; Ein vereinbartes Ziel wird mit konkretem Schritt, offener Voraussetzung und Prüfung verbunden.

9. **Dissens** – m5.html; Ein Vorschlag, den Noah anders sieht, wird als unterschiedliche Auffassung dokumentiert statt als Zustimmung.

10. **Beobachtung** – handlungssituation.html; Eine dokumentierte Verspätung wird von einer Rückkehr unterschieden, bei der nur der Eintrag der Fachkraft fehlt.

11. **Informationslücke** – m5.html; Ohne persönliche Beträge oder vollständigen Stundenplan werden keine neuen tatsächlichen Geld- oder Terminangaben erfunden.

12. **Evaluation** – m5.html; Das Protokoll hält fest, wie die Vereinbarung überprüft wird und wie Noah die Rückmeldung erhält.

