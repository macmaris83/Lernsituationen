# Quellenzuordnung · LS 7.3: Berufswege planen

Ausgangspaket: `SozPaed_LS7_3_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Berufsausbildung** – m3.html; Emilia prüft einen konkreten sozialpädagogischen Bildungsweg statt nur eine Erzählung über viel Praxis zu übernehmen.

2. **Weiterbildung** – m1.html; Bei Benedikts möglicher Veränderung wird nach einer tatsächlichen Erweiterung seiner beruflichen Möglichkeiten gefragt.

3. **Selbstwirksamkeit** – m2.html; Zutrauen in die eigene Entwicklung kann eine Planung unterstützen, ersetzt aber keine formale Aufnahmevoraussetzung.

4. **Kompetenz** – m2.html; Emilias getrennte Beobachtungs- und Vermutungsnotiz ist ein konkreter Ausgangspunkt für ihren Fähigkeitsabgleich.

5. **Zugangsvoraussetzung** – handlungssituation.html; „Abitur reicht bestimmt“ wird an der Originalinformation eines konkreten Angebots geprüft.

6. **Primärquelle** – m3.html; Die MK-Übersicht und die Originalseite des Studiengangs dienen als Einstieg für verlässliche Angebotsangaben.

7. **Quellenprüfung** – m3.html; Abschluss, Inhalte, Praxis, Dauer und Bewerbung werden mit Quelle und Abrufdatum festgehalten.

8. **Zielkonflikt** – m4.html; Emilia wägt häufigen Kinderkontakt und vertiefte fachliche Auseinandersetzung anhand tatsächlicher Angebotsmerkmale ab.

9. **Handlungsplan** – m3.html; Eine Wegeskizze verbindet Ausgangslage, notwendige Voraussetzung, Klärungsschritt und nächste mögliche Handlung.

10. **Informationslücke** – m3.html; Die Recherchemappe enthält noch keine individuelle Zulassungszusage.

11. **Reichweite eines Belegs** – m2.html; Ein gelungener Beobachtungsabsatz beweist noch nicht, dass Emilia dies in vielen Situationen selbstständig leistet.

12. **Beteiligung** – m4.html; Die persönliche Berufsrichtung entscheidet die Person selbst; das Team kann eine dringende Recherchefrage gemeinsam klären.

