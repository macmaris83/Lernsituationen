# Quellenzuordnung · LS 3.1: Sozialisation analysieren

Ausgangspaket: `SozPaed_LS3_1_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Sozialisation** – m2.html; Emilias FSJ verbindet eigene Berufsvorstellungen mit Erfahrungen im Team und in der Arbeit mit Kindern.

2. **Sozialisationsinstanz** – m5.html; Die Einrichtung und ihre Anleitung wirken an Emilias beruflicher Entwicklung mit.

3. **Adoleszenz** – m1.html; Emilias Berufssuche wird als Entwicklungsfrage der 18-Jährigen betrachtet, nicht als Diagnose.

4. **Entwicklungsaufgabe** – m2.html; Emilia möchte berufliche Orientierung und verantwortbare Mitarbeit miteinander verbinden.

5. **Innere Realität** – m1.html; Emilias Interesse am Kinderkontakt gehört zu den persönlichen Voraussetzungen ihrer Entwicklung.

6. **Äußere Realität** – m2.html; Aufgabenverteilung und Rückmeldungen im Regenbogenland prägen die Möglichkeiten des Lernens.

7. **Produktive Realitätsverarbeitung** – m3.html; Emilia stellt Rückfragen und möchte Verantwortung erproben, statt nur Teamvorgaben passiv zu übernehmen.

8. **Perspektivwechsel** – m2.html; Anastasia braucht verlässliche Absprachen; Emilia möchte verstehen, wann eine Rückfrage erwartet wird.

9. **Pädagogischer Auftrag** – m4.html; Die Anleitung unterstützt Emilias Lernen und ersetzt keine Entscheidung über ihren gesamten Berufsweg.

10. **Informationslücke** – m5.html; Zu familiären Erwartungen und Freundschaften liegen keine konkreten Aussagen vor.

11. **Datensparsamkeit** – m5.html; Emilia muss nicht zu jeder privaten Rubrik der Lebensweltkarte eine Auskunft geben.

12. **Entwicklungsziel** – m4.html; Ein nächster Versuch soll die konkrete Übergabe klären, statt Emilia pauschal als geeignet oder ungeeignet zu bewerten.

