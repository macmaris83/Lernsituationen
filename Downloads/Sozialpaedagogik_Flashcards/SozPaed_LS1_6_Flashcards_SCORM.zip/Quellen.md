# Quellenzuordnung · LS 1.6: Praxiskompetenz reflektieren

Ausgangspaket: `SozPaed_LS1_6_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Kompetenz** – handlungssituation.html; Anastasia fragt nach einer Entscheidung, die jede Person selbst erklären und auf veränderte Bedingungen beziehen kann.

2. **Kompetenzbeleg** – m2.html; Ein ausgewählter eigener Abschnitt wird mit genauer Stelle, Entstehung und benötigter Hilfe vorgelegt.

3. **Selbsteinschätzung** – m3.html; Die persönliche Bilanz unterscheidet enge Hilfe, einzelne Hilfen und begründetes selbstständiges Handeln.

4. **Eigenanteil** – m2.html; Vier Namen auf einer Gruppenmappe zeigen noch nicht, wer die fachliche Begründung selbst geleistet hat.

5. **Fremdrückmeldung** – m2.html; Eine vorhandene Rückfrage oder Rückmeldung wird mit ihrer Herkunft dem eigenen Nachweis zugeordnet.

6. **Informationslücke** – m3.html; Eine fehlende Gelegenheit zur Anwendung wird nicht automatisch als persönliches Unvermögen bewertet.

7. **Transfer** – m4.html; Bei einer veränderten Zuständigkeit soll der Rückmeldeweg angepasst werden, ohne das Regelziel aufzugeben.

8. **Entwicklungsziel** – m4.html; Die Person benennt eine konkrete nächste Fähigkeit statt nur „Ich möchte besser werden“.

9. **Zuständigkeit** – m1.html; Aus einer gelungenen Darstellung entsteht keine neue Aufsichts- oder Entscheidungsbefugnis.

10. **Reichweite eines Belegs** – m3.html; Ein eigener Beobachtungsabsatz belegt nicht automatisch die selbstständige Begründung einer ganzen Gruppenplanung.

11. **Überarbeitung** – m2.html; Eine heutige Anwendung wird als heutiger Nachweis datiert und nicht nachträglich als frühere Leistung ausgegeben.

12. **Reflexion** – m3.html; Emilia unterscheidet, welchen Satz sie nur vorlesen und welche Entscheidung sie bei Rückfragen selbst erklären kann.

