# Quellenzuordnung · LS 7.4: Kompetenzen bilanzieren

Ausgangspaket: `SozPaed_LS7_4_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Kompetenzbilanz** – m2.html; Die Übersicht verbindet nachgewiesenes Können mit genauer Stelle, benötigter Hilfe und offener Grenze.

2. **Kompetenzbeleg** – m1.html; Eine datierte Überarbeitung zeigt, wie eine beobachtende Formulierung statt einer Deutung entstanden ist.

3. **Eigenanteil** – m1.html; Emilias Name an der Materialliste belegt nicht automatisch ihren Anteil an der fachlichen Begründung.

4. **Überarbeitung** – m4.html; Erstfassung und spätere Fassung bleiben nebeneinander erhalten, damit Entwicklung nachvollziehbar wird.

5. **Transfer** – m3.html; Eine frühere Bauplanung wird für das Angebot am Gestaltungstisch auf veränderte Bedingungen geprüft.

6. **Lernumgebung** – m3.html; Das Bauangebot steht nun am Tisch; Theos angefangenes Bauwerk ist noch in der bisherigen Bauecke sichtbar.

7. **Beobachtung** – m3.html; Martha betrachtet eine Bildkarte aus Abstand, setzt sich aber zunächst nicht an den Tisch.

8. **Hypothese** – m3.html; Ihr Fernbleiben wird nicht ohne Rückfrage als mangelndes Interesse gewertet.

9. **Ressourcenorientierung** – m3.html; Fabian baut weiter, während andere Kinder anders auf den neuen Angebotsort reagieren.

10. **Reichweite eines Belegs** – m2.html; Eine umfangreiche Gruppenplanung trägt nur die Aussagen über eigenes Können, die an einem eigenen Beitrag belegbar sind.

11. **Informationslücke** – handlungssituation.html; Aus Unsicherheit im neuen Fall folgt nicht, dass alle bisher gezeigten Kompetenzen fehlen.

12. **Reflexion** – m4.html; Die Person erläutert, welche neue Information ihre erste Entscheidung verändert und weshalb.

