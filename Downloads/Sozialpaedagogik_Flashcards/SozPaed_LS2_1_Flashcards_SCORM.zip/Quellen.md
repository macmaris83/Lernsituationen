# Quellenzuordnung · LS 2.1: Beobachtungen dokumentieren

Ausgangspaket: `SozPaed_LS2_1_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Systematische Beobachtung** – m4.html; Für die Übergabe werden eine klare Frage und ein überschaubares Beobachtungsblatt benötigt.

2. **Halo-Effekt** – handlungssituation.html; Simons Verhalten in einer Aufgabe wird vorschnell zum Gesamturteil „nie konzentriert“.

3. **Erwartungseffekt** – handlungssituation.html; Wer Fabian nur als Burgenbauer erwartet, könnte seine Rückfrage bei einem neuen Auftrag übersehen.

4. **Beobachtung** – handlungssituation.html; Simon wartet beim Bewegungsspiel auf das Startzeichen und zeigt einem anderen Kind den Weg.

5. **Etikettierung** – handlungssituation.html; „Nur Ritterburgen interessieren ihn“ fasst Fabian pauschal zusammen und lässt andere Situationen weg.

6. **Operationale Definition** – m4.html; „Unterstützung benötigen“ müsste durch konkret erkennbare Handlungen im gewählten Ausschnitt beschrieben werden.

7. **Dokumentation** – m2.html; Die übernehmende Kollegin braucht Situation, Handlung, Unterstützung und weiteren Verlauf.

8. **Übergabe** – handlungssituation.html; Eine Kollegin, die nicht dabei war, soll nachvollziehen können, was tatsächlich geschehen ist.

9. **Ressourcenrahmen** – m4.html; Für die Übergabe stehen zehn Minuten zur Verfügung; das Verfahren muss dafür nutzbar sein.

10. **Objektivität** – m1.html; Zwei Personen sollen dieselben Notizen möglichst anhand derselben Kriterien auswerten.

11. **Vergleichbarkeit** – m1.html; Gesellschaftsspiel, Bewegungsspiel und neuer Tischauftrag haben unterschiedliche Anforderungen.

12. **Reflexion** – m2.html; Das Team prüft, ob seine kurzen Bewertungen passende Hilfen ermöglichen oder unterschiedliche Deutungen erzeugen.

