# Quellenzuordnung · LS 1.1: Berufsrolle begründen

Ausgangspaket: `SozPaed_LS1_1_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Alltagstheorie** – handlungssituation.html; Emilia meint, manche Kinder brauchten einfach mehr Konsequenz; eine systematische Prüfung fehlt.

2. **Wissenschaftliche Erkenntnis** – m3.html; Die Aufräumaufzeichnungen sollen nachvollziehbar geprüft werden, bevor daraus eine allgemeine Aussage über Lob entsteht.

3. **Pädagogische Handlungskompetenz** – m1.html; Die Praxisgruppe soll Entscheidungen im Vormittag fachlich begründen und bei unklaren Fragen nachfragen.

4. **Beobachtung** – m4.html; Eine Baueckennotiz hält fest, was Theo getan hat, statt ihm sofort eine feste Eigenschaft zuzuschreiben.

5. **Deutung** – m4.html; Die Einschätzung eines Kindes wird in der Teamsitzung mit den tatsächlich notierten Handlungen verglichen.

6. **Fallbeleg** – handlungssituation.html; Anastasia fragt Emilia, an welcher konkreten Stelle sie ihre Einschätzung festgemacht hat.

7. **Berufsrolle** – m1.html; Emilia unterstützt als FSJ-Kraft nach Absprache und übernimmt nicht automatisch die Verantwortung der Gruppenleitung.

8. **Zuständigkeit** – m1.html; Bei unklaren Entscheidungen wendet sich die neue Praxisgruppe an die vereinbarte Ansprechperson.

9. **Ressourcenorientierung** – handlungssituation.html; Theos Bauinteresse und Marthas Interesse an Büchern werden als Möglichkeiten der Kinder berücksichtigt.

10. **Informationslücke** – m3.html; Eine kurze Aufzeichnung erlaubt noch keine umfassende Aussage über das Kind oder die Wirkung einer Maßnahme.

11. **Perspektivwechsel** – handlungssituation.html; Theresa fragt, was die Kinder in dem Moment brauchten, während Benedikt auf die praktische Alltagssituation schaut.

12. **Reflexion** – m4.html; Emilias erste Einschätzung wird mit weiteren Beobachtungen und den Rückfragen des Teams überprüft.

