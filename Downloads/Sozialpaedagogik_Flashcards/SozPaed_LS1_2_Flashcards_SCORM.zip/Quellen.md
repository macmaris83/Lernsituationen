# Quellenzuordnung · LS 1.2: Erziehungsbedingungen beurteilen

Ausgangspaket: `SozPaed_LS1_2_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Erziehungsbedingungen** – m2.html; Bei Theo unterscheiden sich Ansprache und Baumaterial zwischen den beobachteten Situationen.

2. **Eigenaktivität** – m1.html; Leyla nimmt später selbst Material und beginnt einen Kontakt zu einem anderen Kind.

3. **Unterstützungsbedarf** – handlungssituation.html; Bei Leyla soll geklärt werden, wann Begleitung hilft und wann sie selbst handeln kann.

4. **Beobachtung** – m1.html; Theo zeigt eine Öffnung in seinem Bauwerk und sagt am Dienstag „hier durch“.

5. **Hypothese** – m3.html; Die Geburt von Theos Schwester wird als mögliche Erklärung genannt, ohne datierte Vergleichsbeobachtung.

6. **Etikettierung** – handlungssituation.html; Die Überschrift „sprachlich schwach“ blendet Theos Zeigen und seine kurzen Äußerungen aus.

7. **Ressourcenorientierung** – m1.html; Theos Materialangebot und Leylas selbst begonnener Kontakt werden neben den Schwierigkeiten betrachtet.

8. **Überforderung** – m4.html; Emilia befürchtet, Leyla mit zu wenig Begleitung allein zu lassen; diese Befürchtung braucht konkrete Beobachtungen.

9. **Zuständigkeit** – m2.html; Die Praxisgruppe stimmt einen Unterstützungsversuch mit der erreichbaren Fachkraft ab.

10. **Vergleichbarkeit** – m2.html; Mehr Fragen in einer Szene und mehr Wartezeit in einer anderen müssen beim Gegenüberstellen berücksichtigt werden.

11. **Informationslücke** – m3.html; „Zu Hause anders“ nennt keine konkrete Situation und trägt deshalb noch keine sichere Erklärung.

12. **Reflexion** – m3.html; Das Team prüft die alten Überschriften an den neu hinzugekommenen Hinweisen.

