# Quellenzuordnung · LS 1.3: Beziehungen gestalten

Ausgangspaket: `SozPaed_LS1_3_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Professionelle Beziehung** – handlungssituation.html; Emilia möchte Leyla zugewandt begleiten und zugleich ihre Zusagen an andere Kinder beachten.

2. **Empathie** – m2.html; Vor einer Antwort wird geklärt, was Leylas Nähe oder Theos stilles Zeichen für das jeweilige Kind bedeutet.

3. **Nähe und Distanz** – m2.html; Leylas Vertrauen soll ernst genommen werden, ohne Emilia als jederzeit allein verfügbare Person zu versprechen.

4. **Kontaktangebot** – handlungssituation.html; Theo hält einen Stein hoch und schaut zur Praxisgruppe; dieses leise Signal wird zunächst übersehen.

5. **Verlässlichkeit** – handlungssituation.html; Martha wartet nach der Zusage „gleich“, ohne zu wissen, wann Emilia zum Buch kommt.

6. **Informationslücke** – handlungssituation.html; Das Team weiß nicht, ob Theo Hilfe oder Aufmerksamkeit für seine Idee wollte.

7. **Übergabe** – m1.html; Emilia wird zum Tisch gerufen, ohne ihre bisherige Begleitung ausdrücklich mit einer anderen Person abzusprechen.

8. **Zuständigkeit** – m4.html; Ein Zuruf ersetzt nicht die Klärung, wer bei gleichzeitigen Anliegen welche Aufgabe übernimmt.

9. **Beteiligung** – m2.html; Die Kinder erhalten eine verständliche Erklärung, wie ihre Anliegen im weiteren Ablauf aufgegriffen werden könnten.

10. **Perspektivwechsel** – handlungssituation.html; Leylas Erwartung, Marthas Warten und die Aufgaben des Teams werden gemeinsam betrachtet.

11. **Fallbeleg** – m1.html; Die eigene Begründung verweist auf die Garten-, Bau- oder Buchnotiz statt auf ein allgemeines „Ich bin freundlich“.

12. **Reflexion** – m3.html; Emilia überprüft, was ihre unbestimmte Zusage für die Kinder und für das Team bedeutet hat.

