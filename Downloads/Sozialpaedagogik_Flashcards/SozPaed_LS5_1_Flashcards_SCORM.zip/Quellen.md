# Quellenzuordnung · LS 5.1: Jugendhilfe strukturieren

Ausgangspaket: `SozPaed_LS5_1_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Kinder- und Jugendhilfe** – m4.html; Das Team ordnet allgemeine Aufgaben ein, ohne Toms unbekannte Akte mit Annahmen zu ergänzen.

2. **Öffentlicher Träger** – m3.html; Das Jugendamt steht auf dem Kontaktblatt; sein konkreter Beitrag zur offenen Tagesabsprache muss geklärt werden.

3. **Freier Träger** – m3.html; Die Trägerschaft der Klippensteiger ist im vorliegenden Ausschnitt nicht angegeben.

4. **Hilfe zur Erziehung** – m4.html; Allgemeine Rechtsgrundlagen werden von Toms tatsächlich dokumentierten Verhältnissen getrennt.

5. **Personensorge** – m2.html; Ein Bezug zur Familie beweist noch nicht, wer für Tom eine konkrete Entscheidung treffen darf.

6. **Lebenswelt** – handlungssituation.html; Für Tom sind Wohngruppe, Familie und Bildungsort mit seinem tatsächlichen Tagesablauf verbunden.

7. **Zuständigkeit** – m2.html; „Mit Familie klären“ benennt noch keine Fachkraft, die sich um die offene Rückmeldung kümmert.

8. **Netzwerkplan** – m3.html; Tom steht im Mittelpunkt; jede Verbindung benötigt einen konkreten Zweck und einen belegten Kontaktstand.

9. **Rückmeldeweg** – m4.html; Tom und der nächste Dienst sollen erfahren, was für den kommenden Nachmittag tatsächlich vereinbart wurde.

10. **Informationslücke** – m2.html; Ursache der Unterbringung und personensorgeberechtigte Person sind in den Unterlagen nicht genannt.

11. **Datensparsamkeit** – m1.html; Ulla benötigt die Mahlzeitenrückmeldung, nicht die vollständige Fallakte.

12. **Dokumentation** – m1.html; Verfassende, Datum, zuständige Rolle und offener Stand machen die Übergabe nachvollziehbar.

