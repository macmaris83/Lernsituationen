# Quellenzuordnung · LS 1.4: Regeln begründen

Ausgangspaket: `SozPaed_LS1_4_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Regel** – m2.html; Vor dem Verlassen des Gruppenraums sollen Kinder einer erwachsenen Person Bescheid sagen.

2. **Erziehungsziel** – handlungssituation.html; Die Regel soll einen verlässlichen Überblick ermöglichen, während Kinder ihre Anliegen äußern können.

3. **Rollenkonflikt** – m3.html; Hamide möchte Justus als Mutter zuhören und muss zugleich als Leitung eine nachvollziehbare Regelung vertreten.

4. **Beobachtung** – m1.html; Justus geht ins Büro; die protokollierende Person hat eine mögliche vorherige Mitteilung nicht sicher erfasst.

5. **Informationslücke** – m1.html; Aus „Ich habe nichts gehört“ folgt nicht, dass Justus niemandem Bescheid gesagt hat.

6. **Gleichbehandlung** – handlungssituation.html; Ein anderes Kind fragt, ob der für Justus beobachtete Bürogang auch ihm offensteht.

7. **Ausnahme** – m2.html; Ein abweichender Kontakt zum Büro müsste begründet und gegenüber den Kindern verständlich geklärt werden.

8. **Zuständigkeit** – m2.html; Die Praxisgruppe nimmt ein Anliegen auf, legt aber keine eigenen Ausnahmebefugnisse fest.

9. **Rückmeldeweg** – m3.html; Gruppe und Büro müssen ausdrücklich klären, wie der Aufenthalt eines Kindes bestätigt wird.

10. **Abwägung** – m4.html; Verabredete Kontaktzeiten und Kontakte im laufenden Alltag werden auf dringende Anliegen und Umsetzbarkeit geprüft.

11. **Transparenz** – handlungssituation.html; Benedikt braucht eine Erklärung, die das Kind versteht und die zur tatsächlich vereinbarten Regel passt.

12. **Reflexion** – m1.html; Die mögliche Sonderbehandlung wird geprüft, ohne unbekannte Absprachen als Tatsache zu behaupten.

