# Quellenzuordnung · LS 2.4: Übergänge begleiten

Ausgangspaket: `SozPaed_LS2_4_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Transition** – handlungssituation.html; Gülcans Schulwechsel verändert mehr als den Ort: Erwartungen und Möglichkeiten müssen neu geklärt werden.

2. **Ressourcen** – m1.html; Gülcans Interesse am Ausprobieren kann als Ausgangspunkt für die Übergangsbegleitung dienen.

3. **Coping** – m1.html; Die Begleitung betrachtet, wie Gülcan mit Fragen und Unsicherheit zum Schulwechsel umgeht.

4. **Problemorientiertes Coping** – m4.html; Eine konkrete Schulfrage könnte durch einen abgestimmten Informationsschritt bearbeitet werden.

5. **Emotionsorientiertes Coping** – m4.html; Eine Sorge könnte im Gespräch aufgenommen werden, auch wenn die Schulbedingungen noch nicht feststehen.

6. **Resilienz** – m3.html; Verlässliche Unterstützung kann Bewältigung erleichtern, garantiert aber keinen problemlosen Schulstart.

7. **Beteiligung** – handlungssituation.html; Gülcans Fragen zum Ausprobieren und zur eigenen Fragezeit gehören neben Termine in die Planung.

8. **Verlässlichkeit** – m2.html; Benedikts mögliche berufliche Veränderung wird nicht als bereits beschlossener Abschied angekündigt.

9. **Perspektivwechsel** – m1.html; Das Team betrachtet den Schulwechsel aus Gülcans Sicht statt nur als Erwachsenenliste von Anforderungen.

10. **Informationslücke** – handlungssituation.html; Wie Theo die Veränderungen nach der Geburt seiner Schwester empfindet, ist noch nicht dokumentiert.

11. **Handlungsplan** – m4.html; Ein nächster Schritt verbindet Gülcans Anliegen, eine zuständige Rolle und eine geklärte Rückmeldung.

12. **Evaluation** – m4.html; Der Plan soll zeigen, woran die Passung der Begleitung geprüft werden kann, ohne einen Erfolg vorwegzunehmen.

