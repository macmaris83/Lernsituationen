# Quellenzuordnung · LS 4.4: Schutzfaktoren fördern

Ausgangspaket: `SozPaed_LS4_4_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Schutzfaktor** – m2.html; Verlässliche Begleitung könnte unterstützen; aus einem Studienbegriff folgt keine Erfolgsgarantie für den Kita-Alltag.

2. **Risikofaktor** – m2.html; Wiederholtes Warten lenkt eine Prüffrage auf Zugänge; es beweist noch keine individuelle Belastungslage.

3. **Resilienz** – m1.html; Die Entwicklung unter Belastung wird nicht als automatisch erzeugbares Ergebnis eines neuen Angebots behandelt.

4. **Längsschnittstudie** – m1.html; Die Kauai-Untersuchung betrifft Entwicklung über viele Jahre und nicht die kurze Beobachtung einer Kita-Aktion.

5. **Korrelation** – m1.html; Ein Forschungszusammenhang kann eine Prüffrage anregen, ohne die Ursache eines einzelnen Kita-Verlaufs zu beweisen.

6. **Kausalität** – m2.html; Vor der Behauptung einer Wirkung müsste mehr belegt sein als das gemeinsame Auftreten einer Maßnahme und eines Verhaltens.

7. **Prävention** – m4.html; Ein veränderter Alltagsablauf soll begründete Zugänge stärken, statt nur eine zusätzliche Aktion anzubieten.

8. **Beteiligung** – m3.html; Eine umgesetzte Kinderidee zeigt noch nicht, ob stillere Kinder ebenfalls Einfluss hatten.

9. **Ressourcenrahmen** – handlungssituation.html; Es gibt keine zusätzliche Stelle; täglich sind höchstens zehn zusätzliche Dokumentationsminuten vorgesehen.

10. **Quellenprüfung** – m1.html; Die Aussagen aus frei zugänglichen Abstracts werden mit ihrer untersuchten Lebenslage und Reichweite gelesen.

11. **Transfer** – m1.html; Das Team prüft, welche Forschungsfrage zum eigenen Alltag passt und welche Unterschiede berücksichtigt werden müssen.

12. **Evaluation** – handlungssituation.html; Für die erneute Besprechung in zwei Wochen werden konkrete Merkmale der Veränderung benötigt.

