# Quellenzuordnung · LS 6.5: Teilhabe konzipieren

Ausgangspaket: `SozPaed_LS6_5_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Teilhabe** – m1.html; Das Konzept soll Jana, Leon und Aylin passende Zugänge mit erkennbarem Einfluss ermöglichen.

2. **Konzeptbaustein** – m2.html; Gute Absichten werden mit konkreten Schritten, Rollen und Prüfmöglichkeiten verbunden.

3. **Entscheidungsspielraum** – handlungssituation.html; Jana fragt, wann der Inhalt noch verändert werden kann und was bereits feststeht.

4. **Transparenz** – m4.html; „Ideen werden berücksichtigt“ muss erklären, wie das Team mit einem konkreten Vorschlag umgeht.

5. **Digitale Beteiligung** – m1.html; Aylin möchte erkennen, was aus ihrem übermittelten Beitrag im weiteren Verfahren wird.

6. **Zugangsbarriere** – m1.html; Leons offene Terminfrage muss bearbeitet werden, bevor verlässliche Teilnahme erwartet wird.

7. **Ressourcenrahmen** – m2.html; Ein Termin im bestehenden Öffnungsrahmen ist vorgesehen; zusätzliche Personalstunden sind nicht zugesagt.

8. **Zuständigkeit** – m2.html; Jeder Konzeptschritt benennt die Rolle, die ihn mit den vorhandenen Möglichkeiten übernimmt.

9. **Rückmeldeweg** – m4.html; Die Antwort auf eine Idee oder Terminanfrage muss die betreffende Person tatsächlich erreichen.

10. **Fallbeleg** – m3.html; Eine vorgeschlagene Maßnahme wird mit einer genauen Ausgangsstelle aus der Quellenmappe verbunden.

11. **Ergebniskriterium** – m4.html; Das Team beschreibt, woran ein tatsächlich genutzter Entscheidungsspielraum erkennbar wäre.

12. **Evaluation** – m4.html; Die Rollenprobe prüft, ob Jugendliche und Trägerperspektive den Entwurf verständlich und umsetzbar finden.

