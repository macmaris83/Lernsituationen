# Quellenzuordnung · LS 4.2: Unterstützungsmaßnahmen entwickeln

Ausgangspaket: `SozPaed_LS4_2_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Beobachtung** – m1.html; Pavel fragt nach Arbeitsschritten; Lene beginnt bei einer Aufgabe zunächst nicht.

2. **Hypothese** – m2.html; Die Vermutung „fehlender Wille“ erklärt Lenes Nichtbeginn noch nicht und muss an weiteren Informationen geprüft werden.

3. **Diagnose** – m1.html; Die Fallnotizen enthalten keine diagnostische Untersuchung Pavels oder Lenes.

4. **ADHS** – m2.html; Das Wort wird zu Pavel genannt, obwohl die beobachteten Ausschnitte keinen klinischen Befund liefern.

5. **Unterstützungsbedarf** – m3.html; Beide bearbeiten mit Unterstützung mehr; gefragt wird nach dem passenden Aufgabenstart.

6. **Ressourcenorientierung** – m1.html; Lenes erklärender Beitrag und die Gruppendarstellungen werden neben unvollständigen Blättern berücksichtigt.

7. **Pädagogischer Auftrag** – m4.html; Das Team verändert die Lernbedingungen im bestätigten schulischen Aufgabenbereich statt selbst zu diagnostizieren.

8. **Beteiligung** – m1.html; Pavel möchte keine öffentlichen Ermahnungen; Lene möchte ihre Rückfragen einbringen können.

9. **Unterstützungsversuch** – m3.html; Vorhandene Hilfekarten oder ein geklärter Anfangskontakt könnten in einem abgestimmten Versuch erprobt werden.

10. **Vergleichbarkeit** – m5.html; Simons und Fabians Notizen betreffen andere Personen und liefern keine zusätzlichen Beobachtungen zu Pavel oder Lene.

11. **Ergebniskriterium** – m3.html; Vor dem Versuch wird geklärt, woran ein verständlicher nächster Arbeitsschritt erkennbar wäre.

12. **Evaluation** – m3.html; Die Rückmeldung der beiden wird mit dem dokumentierten Arbeitsverlauf verglichen, bevor eine Unterstützung bewertet wird.

