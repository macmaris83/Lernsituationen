# Quellenzuordnung · LS 2.5: Praxis auswerten

Ausgangspaket: `SozPaed_LS2_5_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Evaluation** – m1.html; Das Team beurteilt das Bauangebot anhand der geplanten Ziele und der vorhandenen Verlaufsnotizen.

2. **Validität** – handlungssituation.html; Fertige Türme zeigen nicht allein, ob Kinder Bauweisen verändert und Beobachtungen ausgedrückt haben.

3. **Reliabilität** – m3.html; Eine wiederholte Auswertung müsste vergleichbare Kriterien nutzen, statt jedes Mal eine andere Vorstellung von Erfolg.

4. **Objektivität** – m3.html; Das Urteil „gut geklappt“ wird durch gemeinsame Kriterien und auffindbare Beobachtungen geprüft.

5. **Ergebniskriterium** – m1.html; Zur Planung gehört, dass Kinder eine Bauweise verändern oder eine Beobachtung äußern können.

6. **Beobachtung** – handlungssituation.html; Ein Kind nimmt erst nach einer Nachfrage Material; dieser Verlauf wird neben den fertigen Türmen betrachtet.

7. **Anwesenheit und Teilhabe** – m2.html; Die Anwesenheit am Bauplatz belegt nicht, dass jedes Kind Gelegenheit zur geplanten Erkundung hatte.

8. **Qualitätsentwicklung** – m3.html; Vor einer Wiederholung prüft das Team, welche Begleitung verändert werden sollte.

9. **Ressourcenorientierung** – handlungssituation.html; Zwei Kinder möchten weiterbauen; dieses Interesse wird aufgegriffen, ohne daraus den Erfolg für alle abzuleiten.

10. **Fremdrückmeldung** – m4.html; Emilias Eintrag wird mit konkreten Rückfragen aus dem Anleitungsgespräch verbunden.

11. **Selbsteinschätzung** – m4.html; Emilia fragt, woran sie die eigene Entwicklung erkennen kann, statt nur die gelungene Aktion zu bewerten.

12. **Reichweite eines Belegs** – m2.html; Ein kurzer Modellverlauf trägt nur die darin tatsächlich beobachteten Aussagen.

