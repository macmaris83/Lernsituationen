# Quellenzuordnung · LS 2.2: Entwicklung einordnen

Ausgangspaket: `SozPaed_LS2_2_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Anlage** – m3.html; Eine kurze Beobachtung beim Elternabend erlaubt keine Aussage über die genetischen Voraussetzungen des Kindes.

2. **Reifung** – m3.html; Altersangaben werden fachlich eingeordnet, statt aus einer einzelnen Szene eine feste Entwicklungsgrenze abzuleiten.

3. **Umwelt** – handlungssituation.html; Dass ein Kind zu Hause mehr erzählt als in großen Runden, lenkt den Blick auf unterschiedliche Bedingungen.

4. **Entwicklungsbereiche** – handlungssituation.html; Die Darstellung für Familien soll Bewegung, Sprache, Denken und Zusammenleben miteinander verbinden.

5. **Sensorimotorik** – m1.html; Beim Bauen werden das Wahrnehmen von Material und das gezielte Bewegen der Steine gemeinsam betrachtet.

6. **Assimilation** – m1.html; Als denkbare Einordnung könnte ein Kind eine bekannte Bauidee zunächst auf neues Material übertragen.

7. **Akkommodation** – m1.html; Als denkbare Einordnung könnte ein Kind seine Bauweise verändern, wenn die bisherige Lösung nicht passt.

8. **Emotionsregulation** – m3.html; Die Erklärung für Familien berücksichtigt, dass Gefühle und Unterstützung das Mitmachen beeinflussen können.

9. **Ressourcenorientierung** – handlungssituation.html; Die eigene Lösung beim vertrauten Bauen wird neben Rückfragen im neuen Regelspiel sichtbar gemacht.

10. **Vergleichbarkeit** – handlungssituation.html; Vertrautes Bauen und ein neues Regelspiel dürfen nicht als gleiche Anforderung behandelt werden.

11. **Informationslücke** – m3.html; Die kurzen Notizen tragen keine individuelle Diagnose und keine sichere Altersnorm für das einzelne Kind.

12. **Transparenz** – m4.html; Eine Familiengrafik erklärt ihre Beobachtungsgrundlage und die Grenzen ihrer Aussagen.

