# Quellenzuordnung · LS 4.3: Fallperspektiven koordinieren

Ausgangspaket: `SozPaed_LS4_3_SCORM.zip`. Definitionen sind didaktische Kurzfassungen; Fallbeispiele beziehen sich auf die Modellunterlagen. Als Möglichkeiten formulierte Vorgehensweisen sind keine Behauptung über einen bereits erfolgten Verlauf.

1. **Multiprofessionelle Zusammenarbeit** – m2.html; Alltagsbegleitung, schulische Fachkraft, Leitung und psychologische Beratung bringen verschiedene Fallkontakte ein.

2. **Fallkonferenz** – handlungssituation.html; In 30 Minuten sollen die Beteiligten eine gemeinsame Grundlage für den bevorstehenden Wechsel finden.

3. **Netzwerkplan** – m4.html; Verbindungen werden mit Zweck, Rolle, Informationsumfang und Rückmeldung beschrieben.

4. **Beobachtung** – m1.html; Paula zieht sich bei einer unangekündigten Raumänderung zurück und beteiligt sich in einem anderen Verlauf.

5. **Ressourcenorientierung** – m1.html; Paulas eigener Gruppenentwurf und ihre Rückkehr nach einer vereinbarten Pause werden berücksichtigt.

6. **Diagnose** – m1.html; Ein begrenzter Selbstbericht über einen schweren Unfall ersetzt keine dokumentierte Diagnose.

7. **Beteiligung** – m5.html; Paulas Fragen nach Ort, Pause und Änderungen gehören vor die gemeinsame Festlegung.

8. **Datensparsamkeit** – handlungssituation.html; Paula möchte nicht, dass alle ihre persönliche Geschichte erneut erzählen.

9. **Zuständigkeit** – m5.html; Eine allgemeine Zusage „Paula kann eine Pause machen“ klärt noch nicht, wer dann erreichbar ist.

10. **Rückmeldeweg** – m3.html; Wer eine Raumänderung mitteilt und wie Paula nach einer Pause zurückkommt, muss ausdrücklich vereinbart werden.

11. **Informationslücke** – m4.html; Ein weiterer Beratungstermin kann angefragt werden, ist aber noch nicht bestätigt.

12. **Evaluation** – m5.html; Der gemeinsame Plan benötigt eine nachvollziehbare Überprüfung statt lediglich kurze Zusagesätze.

