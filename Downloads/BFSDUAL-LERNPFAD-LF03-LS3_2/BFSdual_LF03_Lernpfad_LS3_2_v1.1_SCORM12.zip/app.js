'use strict';
const $=s=>document.querySelector(s),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const LEVEL=['','Orientierung','Anwendung','Transfer'],TOTAL=30,TRANSFER_COUNT=6;
let api=null,initialized=false,finished=false,start=Date.now(),ioErrors=[],interaction=0;
function findAPI(w){for(let i=0;i<20&&w;i++){try{if(w.API)return w.API;if(w.parent===w)break;w=w.parent}catch(e){break}}return null}
api=findAPI(window);if(!api){try{api=findAPI(window.opener)}catch(e){}}
function get(k){try{return initialized?api.LMSGetValue(k):''}catch(e){return ''}}
function set(k,v){if(!initialized)return;try{if(String(api.LMSSetValue(k,String(v)))!=='true')ioErrors.push(k)}catch(e){ioErrors.push(k)}}
if(api){try{initialized=String(api.LMSInitialize(''))==='true'}catch(e){}}
let s=Engine.initial(),legacyAttempt=false;
try{
 const storageKey=PACKAGE.id+'-learner-v1';
 let raw='';
 if(initialized){
  const entry=String(get('cmi.core.entry')||'').toLowerCase();
  const lessonStatus=String(get('cmi.core.lesson_status')||'').toLowerCase();
  // SCORM 1.2: Nur einen ausdrücklich fortgesetzten Versuch wiederaufnehmen.
  // Bei "ab-initio" wurde in Moodle ein neuer Versuch gestartet (z. B. nach
  // dem manuellen Löschen/Zurücksetzen durch die Lehrkraft). Eventuell noch
  // vorhandene suspend_data gehören dann zum alten Versuch und werden ignoriert.
  if(entry==='resume')raw=get('cmi.suspend_data');
  else if(entry==='ab-initio')raw='';
  else{
   // Fallback für LMS, die cmi.core.entry nicht zuverlässig setzen:
   // Ein klar ungestarteter Versuch beginnt neu, ansonsten darf ein vorhandener
   // Zwischenstand weitergeführt werden.
   raw=(lessonStatus===''||lessonStatus==='not attempted'||lessonStatus==='not_attempted')?'':get('cmi.suspend_data');
  }
 }else raw=localStorage.getItem(storageKey);
 if(raw){
  const saved=JSON.parse(raw);
  if(saved.v===1401 && Array.isArray(saved.rows) && saved.rows.length<=TOTAL){
   s=saved;
   if (!s.reserveUses) {
     if (s.remediation?.length && s.screen === 'task' && Number.isInteger(s.current) && s.current < 24) s.hint=0;
     s.reserveUses={};
   }
  }
  else legacyAttempt=true;
 }
}catch(e){}
interaction=Number(get('cmi.interactions._count'))||0;if(initialized&&!legacyAttempt&&!['completed','passed','failed'].includes(get('cmi.core.lesson_status')))set('cmi.core.lesson_status','incomplete');
function status(){const b=$('#status');b.textContent=ioErrors.length?'Speicherung unvollständig. Bitte Lernbericht sichern und die Lehrkraft informieren.':initialized?'Mit Moodle verbunden · Lernweg wird gespeichert.':api?'Moodle-Verbindung konnte nicht gestartet werden. Speicherung nur in diesem Browser.':'Vorschau ohne Moodle · Speicherung nur in diesem Browser.'}
function updateChrome(){const n=s.rows.length,q=s.current!==null?BANK[s.current]:null,level=q?q.l:s.stage;$('#chrome-level').textContent=LEVEL[level]||'Dein Lernweg';$('#chrome-level').className='level level-'+level;$('#chrome-fill').style.width=(n/TOTAL*100)+'%';$('#chrome-pct').textContent=Math.round(n/TOTAL*100)+' %';$('#chrome-track').setAttribute('aria-valuemax',String(TOTAL));$('#chrome-track').setAttribute('aria-valuenow',String(n));$('#chrome-track').setAttribute('aria-valuetext',`${n} von ${TOTAL} Kernaufgaben bearbeitet`);$('#chrome-caption').textContent=`${n} von ${TOTAL} Aufgaben bearbeitet · 12 Orientierung · 12 Anwendung · 6 Transfer`}
function score(){return Engine.score(s)}
function persist(){if(legacyAttempt)return;updateChrome();const raw=JSON.stringify(s);if(initialized){if(raw.length>4096){ioErrors.push('Speichergrenze');status();return}set('cmi.suspend_data',raw);set('cmi.core.lesson_location',`${s.stage}:${s.rows.length}`);set('cmi.core.score.min',0);set('cmi.core.score.max',100);set('cmi.core.score.raw',score());set('cmi.core.exit','suspend');try{if(String(api.LMSCommit(''))!=='true')ioErrors.push('Commit')}catch(e){ioErrors.push('Commit')}}else try{localStorage.setItem(PACKAGE.id+'-learner-v1',raw)}catch(e){ioErrors.push('Browser-Speicher')}status()}
function ident(t){return String(t).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ß/g,'ss').replace(/[^a-zA-Z0-9_-]+/g,'_').slice(0,240)}
function log(id,response,result='neutral',c=null){if(!initialized)return;const n=interaction++,k=`cmi.interactions.${n}.`;set(k+'id',ident(id));set(k+'type','fill-in');if(c!==null)set(k+'objectives.0.id',ident(COMP[c][0]));set(k+'student_response',String(response).slice(0,250));set(k+'result',result);set(k+'time',new Date().toTimeString().slice(0,8))}
function objectives(){for(let c=0;c<5;c++){const a=Engine.evidence(s,c),done=a.filter(r=>typeof r[1]==='number'),k=`cmi.objectives.${c}.`;set(k+'id',ident(COMP[c][0]));set(k+'score.min',0);set(k+'score.max',100);set(k+'score.raw',done.length?Math.round(done.reduce((t,r)=>t+r[1],0)/done.length*100):0);set(k+'status',a.length&&done.length===a.length?'completed':'incomplete')}}
function selfFields(which){const labels=['Ich brauche viel Unterstützung.','Mit Unterstützung gelingt es teilweise.','Vertraute Fälle kann ich weitgehend bearbeiten.','Ich kann es selbstständig und begründet.','Ich kann es auf neue Situationen übertragen.'];return COMP.map((c,i)=>`<div class="selfrow"><label for="self${i}">${c[0]}</label><p>${c[1]}</p><select id="self${i}" data-self="${i}"><option value="0">Bitte einschätzen</option>${labels.map((t,n)=>`<option value="${n+1}" ${s[which][i]===n+1?'selected':''}>${n+1} · ${t}</option>`).join('')}</select></div>`).join('')}
function bindSelf(which,onchange){document.querySelectorAll('[data-self]').forEach(el=>el.onchange=()=>{s[which][+el.dataset.self]=+el.value;persist();onchange&&onchange()})}
function intro(){s.screen='intro';$('#app').innerHTML=`<div class="layout"><section><div class="card hero"><div class="eyebrow">BFS Dual · Lernfeld 3</div><h1>Drei Stufen. Ein Fall.</h1><p>Du startest mit <b>Orientierung</b>, gehst weiter zu <b>Anwendung</b> und erreichst danach <b>Transfer</b>.</p><p>Orientierung und Anwendung haben jeweils <b>12 Aufgaben</b>. Im Transfer triffst du <b>6 zusammenhängende Entscheidungen</b>. Wenn du in Orientierung oder Anwendung unter 66 % erreichst, übst du offene Lernziele an weiteren Aufgaben.</p></div><div class="card"><div class="eyebrow">Vor dem Start</div><h2>Wie sicher fühlst du dich?</h2><p>Schätze alle fünf Bereiche ein.</p>${selfFields('before')}<div id="selfMsg" class="muted"></div><div class="actions"><button id="startLearning" disabled>Lernweg starten</button></div></div></section><aside><div class="card"><h2>Dein Weg</h2><p><b>Orientierung</b> · 12 Aufgaben</p><p><b>Anwendung</b> · 12 Aufgaben</p><p><b>Transfer</b> · 6 Entscheidungen</p><p class="muted">Im Transfer zählt die ganze Entscheidungskette.</p></div></aside></div>`;const check=()=>{const ok=s.before.every(x=>x>=1&&x<=5);$('#startLearning').disabled=!ok;$('#selfMsg').textContent=ok?'✓ Alle fünf Bereiche eingeschätzt.':'Bitte alle fünf Kompetenzbereiche einschätzen.'};bindSelf('before',check);check();$('#startLearning').onclick=()=>{s.optionSeed = newOptionSeed();COMP.forEach((c,i)=>log(`Selbsteinschaetzung_Start_${c[0]}`,`${s.before[i]}/5`,'neutral',i));s.stage=1;s.screen='task';persist();render();window.scrollTo(0,0)}}
function newOptionSeed() {
  if (globalThis.crypto?.getRandomValues) return globalThis.crypto.getRandomValues(new Uint32Array(1))[0];
  return Math.floor(Math.random() * 0x100000000);
}

function oldOptionOrder(n,seed){const a=Array.from({length:n},(_,i)=>i);let x=(seed+1)*1103515245+12345;for(let i=n-1;i>0;i--){x=(x*1664525+1013904223)>>>0;const j=x%(i+1);[a[i],a[j]]=[a[j],a[i]]}return a}
function optionOrder(q, length = q.options.length, offset = 0) {
  const round = Number(s.stageAttempts?.[q.l] || 0);
  const key = q.id + offset;
  // Restore the display order of an attempt that was started with version 1.0.
  if (!Number.isInteger(s.optionSeed)) return oldOptionOrder(length, key + 997 * round);

  const indices = Array.from({length}, (_, i) => i);
  let state = (s.optionSeed + Math.imul(key + 1, 0x9e3779b9) + Math.imul(round, 0x85ebca6b)) >>> 0;
  for (let i = length - 1; i > 0; i--) {
    // Mulberry32 gives a repeatable draw from the stored attempt seed.
    state = (state + 0x6d2b79f5) >>> 0;
    let draw = Math.imul(state ^ (state >>> 15), state | 1);
    draw ^= draw + Math.imul(draw ^ (draw >>> 7), draw | 61);
    const fraction = ((draw ^ (draw >>> 14)) >>> 0) / 0x100000000;
    const j = Math.floor(fraction * (i + 1));
    [indices[i], indices[j]] = [indices[j], indices[i]];
  }
  return indices;
}

function storyScene(q){let txt=q.scene;if(Number.isInteger(q.branchFrom)&&BANK[q.branchFrom]){const from=BANK[q.branchFrom],choice=s.storyAnswers[from.storyIndex];if(Number.isInteger(choice)&&q.branchText?.[choice])txt+='\n\n'+q.branchText[choice]}return txt}
function formatScene(t){return esc(t).split(/\n\n+/).map(p=>`<p>${p.replace(/\n/g,'<br>')}</p>`).join('')}
function inputHTML(q){
 if (['single','story','multi'].includes(q.type)) {
   const control = q.type === 'multi' ? 'checkbox' : 'radio';
   return optionOrder(q).map(i => `<label class="option"><input type="${control}" name="answer" value="${i}"><span>${esc(q.options[i])}</span></label>`).join('');
 }
 if(q.type==='short')return `<label class="short-answer"><span>Deine Antwort</span><input id="shortAnswer" type="text" autocomplete="off"></label>`;
 if (q.type === 'match') {
   const [items,categories] = q.options;
   const order = optionOrder(q, categories.length, 99);
   return items.map((text,i) => `<div class="pair"><span>${esc(text)}</span><select data-match="${i}"><option value="">Bitte wählen</option>${order.map(k => `<option value="${k}">${esc(categories[k])}</option>`).join('')}</select></div>`).join('');
 }
 if (q.type === 'order') {
   const order = optionOrder(q, q.options.length, 33);
   return q.options.map((_,pos) => `<div class="pair"><span>${pos+1}. Position</span><select data-order="${pos}"><option value="">Bitte wählen</option>${order.map(i => `<option value="${i}">${esc(q.options[i])}</option>`).join('')}</select></div>`).join('');
 }
 return ''
}
function readAnswer(q){if(q.type==='single'||q.type==='story'){const x=document.querySelector('input[name=answer]:checked');return x?+x.value:null}if(q.type==='multi')return [...document.querySelectorAll('input[name=answer]:checked')].map(x=>+x.value).sort((a,b)=>a-b);if(q.type==='short')return $('#shortAnswer').value.trim();if(q.type==='match')return [...document.querySelectorAll('[data-match]')].map(x=>x.value===''?null:+x.value);if(q.type==='order')return [...document.querySelectorAll('[data-order]')].map(x=>x.value===''?null:+x.value);return null}
function answerText(q,a){if(q.type==='short')return a;if(q.type==='single'||q.type==='story')return q.options[a]||'';if(q.type==='multi')return a.map(i=>q.options[i]).join(' | ');if(q.type==='match')return q.options[0].map((x,i)=>`${x}: ${q.options[1][a[i]]||'?'}`).join(' | ');if(q.type==='order')return a.map(i=>q.options[i]).join(' → ');return ''}
function correctText(q){if(q.type==='short')return q.answer[0];if(q.type==='single')return q.options[q.answer];if(q.type==='multi')return optionOrder(q).filter(i=>q.answer.includes(i)).map(i=>q.options[i]).join(' · ');if(q.type==='match')return q.options[0].map((x,i)=>`${x} → ${q.options[1][q.answer[i]]}`).join(' · ');if(q.type==='order')return q.answer.map(i=>q.options[i]).join(' → ');return ''}
function storyTrail(q){if(!q.storyIndex)return '';const prev=q.storyIndex-1,prevQ=BANK[CORE_PLAN['3'][prev]],choice=s.storyAnswers[prev];if(!Number.isInteger(choice))return '';return `<div class="story-memory"><div class="eyebrow">Folge deiner letzten Entscheidung</div><p>${esc(prevQ.consequences[choice])}</p></div>`}
function task(){const q=Engine.next(s);if(!q){s.screen='checkpoint';persist();return render()}s.current=q.id;s.screen='task';const story=q.type==='story',scene=story?storyScene(q):q.scene,isRetry=!story&&Array.isArray(s.remediation)&&s.remediation.length>0;$('#app').innerHTML=`<div class="card task-card level-${q.l}"><div class="task-head"><div><div class="eyebrow">${story?`Transferfall · Kapitel ${q.storyIndex+1}/${TRANSFER_COUNT}`:isRetry?`${(s.reserveUses?.[q.coreId] || 0) >= 2 ? 'Wiederholung' : 'Festigungsrunde'} · ${LEVEL[q.l]}`:`${LEVEL[q.l]}`}</div><h1>${esc(q.title)}</h1></div><div class="task-tags"><span class="tag level-tag level-${q.l}">${LEVEL[q.l]}</span><span class="tag">${esc(COMP[q.c][0])}</span></div></div>${storyTrail(q)}<div class="casework"><div class="case-label">${esc(q.caseLabel||'Fall aus Lernfeld 3')}</div><div class="context">${formatScene(scene)}</div><div class="assignment"><div class="eyebrow">Deine Entscheidung</div><div class="question">${esc(q.ask)}</div><p class="muted">${esc(q.criteria||'')}</p></div></div><div class="source-actions"><button class="secondary" type="button" data-open-sources>Fall und Materialien</button></div><form id="form">${inputHTML(q)}<div id="error" class="error"></div>${story?'':`<div class="actions"><button type="button" id="help" class="secondary">${s.hint?`Nächste Hilfe öffnen`:'Hilfe öffnen'}</button><button type="submit">Antwort prüfen</button></div>`}${story?'<div class="actions"><button type="submit">Entscheidung festhalten</button></div>':''}</form><div id="hint" class="hint" hidden></div><div id="feedback"></div></div>`;
 if(!story)$('#help').onclick=()=>{s.hint=Math.min(3,Number(s.hint||0)+1);const texts=[q.hint,q.steps,q.example];$('#hint').hidden=false;$('#hint').innerHTML=`<b>H${s.hint}</b><p>${esc(texts[s.hint-1]||'')}</p>`;$('#help').textContent=s.hint>=3?'Alle Hilfen geöffnet':'Nächste Hilfe öffnen';$('#help').disabled=s.hint>=3;persist()};
 if (!story && s.hint > 0) {
   const texts = [q.hint, q.steps, q.example];
   $('#hint').hidden = false;
   $('#hint').innerHTML = `<b>H${s.hint}</b><p>${esc(texts[s.hint - 1])}</p>`;
   if (s.hint >= 3) { $('#help').textContent = 'Alle Hilfen geöffnet'; $('#help').disabled = true; }
 }
 if (isRetry && Engine.stageGate(s, s.stage).pass) {
   const leave = document.createElement('button');
   leave.type = 'button'; leave.className = 'secondary'; leave.textContent = 'Zur Stufenauswertung';
   leave.onclick = returnToCheckpoint;
   $('#form .actions').append(leave);
 }
 $('#form').onsubmit=e=>{e.preventDefault();const a=readAnswer(q),empty=a===null||a===''||(Array.isArray(a)&&(!a.length||a.some(x=>x===null)))||(q.type==='order'&&new Set(a).size!==a.length);if(empty){$('#error').textContent='Bitte zuerst eine vollständige Entscheidung treffen.';return}if(story)submitStory(q,a);else submitStandard(q,a)}
}
function submitStandard(q, answers) {
  if (s.screen !== 'task' || s.current !== q.id) return;
  const mark = Engine.grade(q, answers);
  const reserve = Number.isInteger(q.coreId);
  Engine.recordStandard(s, q, mark);
  s.screen = 'feedback';
  s.lastMark = mark;
  const interactionId = reserve
    ? `Festigung_${q.coreId + 1}_Variante_${q.reserveNo}_Versuch_${s.reserveUses[q.coreId]}`
    : `Aufgabe_${s.rows.length}_${COMP[q.c][0]}_${LEVEL[q.l]}_${q.title}`;
  log(interactionId, answerText(q, answers), mark === 1 ? 'correct' : 'wrong', q.c);
  objectives();
  persist();
  document.querySelectorAll('#form input,#form select,#form button').forEach(control => control.disabled = true);
  showStandardFeedback(q, mark);
}
function showStandardFeedback(q, mark){$('#feedback').innerHTML=`<div class="feedback"><h2>${mark===1?'Das passt fachlich.':mark>0?'Ein Teil ist tragfähig.':'Hier lohnt sich ein zweiter Blick.'}</h2><p>${esc(q.why)}</p><p><b>Lösung:</b> ${esc(correctText(q))}</p>${q.optionFeedback?`<details class="option-explanation"><summary>Alle sechs Aussagen erklärt</summary><ul>${optionOrder(q).map(i=>`<li><b>${q.answer.includes(i)?"Zutreffend":"Nicht zutreffend"}:</b> ${esc(q.options[i])}<br>${esc(q.optionFeedback[i])}</li>`).join("")}</ul></details>`:""}<p class="muted">${mark===1?(s.hint?'Mit den Hilfen hast du den Zusammenhang jetzt richtig gelöst.':'Du hast diesen Nachweis selbstständig richtig gelöst.'):`Nächster Ansatz: ${esc(q.hint)}`}</p></div><div class="actions"><button id="next">Weiter</button></div>`;$('#next').onclick=nextAfterFeedback}
function submitStory(q,a){s.storyAnswers[q.storyIndex]=a;s.rows.push([q.id,null,0]);log(`Transfer_Kapitel_${q.storyIndex+1}_${q.title}`,answerText(q,a),'neutral',q.c);let finalEval=null;if(q.storyIndex===TRANSFER_COUNT-1){finalEval=Engine.applyStoryEvaluation(s);objectives();if(finalEval)log('Transfer_Gesamtlogik',`${finalEval.label}; ${finalEval.strongCount}/${finalEval.totalRules} Verknüpfungen stark`,'neutral',0)}persist();document.querySelectorAll('#form input,#form button').forEach(el=>el.disabled=true);if(finalEval){const strengths=finalEval.strengths.slice(0,3),issues=finalEval.issues.slice(0,2);$('#feedback').innerHTML=`<div class="story-outcome final"><div class="eyebrow">Feedback zu deiner gesamten Entscheidungskette</div><h2>${esc(finalEval.label)}</h2><p class="decision-line"><b>Deine Linie:</b> ${esc(finalEval.line)}</p><div class="feedback-columns"><section><h3>✓ Das war tragfähig</h3><ul>${strengths.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></section><section><h3>${issues.length?'↯ Hier entstand Spannung':'✓ Kein deutlicher Logikbruch'}</h3>${issues.length?`<ul>${issues.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:'<p>Deine zentralen Entscheidungen greifen durchgängig ineinander.</p>'}</section></div><div class="course-correction"><b>↗ Kurskorrektur:</b> ${esc(finalEval.correctionText)}</div><div class="feedforward"><b>↑ Nächster Schritt:</b> ${esc(finalEval.feedforward)}</div><details><summary>Meine 6 Entscheidungen ansehen</summary><ol class="decision-review">${finalEval.decisions.map(d=>`<li><b>${esc(d.title)}</b><br>${esc(d.choice)}</li>`).join('')}</ol></details><p class="muted">Keine Einzelentscheidung wurde isoliert als richtig oder falsch bewertet. Die Rückmeldung entsteht aus den Beziehungen zwischen deinen Entscheidungen.</p></div><div class="actions"><button id="next">Zur Transfer-Auswertung</button></div>`}else{$('#feedback').innerHTML=`<div class="story-outcome"><div class="eyebrow">Entscheidung gespeichert</div><h2>Die Situation entwickelt sich weiter.</h2><p>${esc(q.consequences[a])}</p><p class="muted">Du bekommst bewusst noch keine Richtig-/Falsch-Rückmeldung. Die nächste Situation baut auf deinem Weg auf.</p></div><div class="actions"><button id="next">Nächstes Kapitel</button></div>`}$('#next').onclick=nextAfterFeedback}
function nextAfterFeedback(){delete s.lastMark;s.current=null;s.hint=0;if(Array.isArray(s.remediation)&&s.remediation.length)s.screen='task';else if(Engine.stageRows(s,s.stage).length>=Engine.plan(s.stage).length)s.screen='checkpoint';else s.screen='task';persist();render();window.scrollTo(0,0)}
function stageReveal(from,to){document.querySelectorAll('.level-reveal').forEach(x=>x.remove());const o=document.createElement('div');o.className=`level-reveal reveal-${to}`;o.innerHTML=`<div class="reveal-card"><div class="reveal-scan"></div><div class="reveal-kicker">NÄCHSTE STUFE</div><div class="reveal-arrow">↑</div><div class="reveal-from">${LEVEL[from]}</div><div class="reveal-title">${LEVEL[to]}</div><div class="reveal-status">FREIGESCHALTET</div></div>`;document.body.appendChild(o);setTimeout(()=>o.classList.add('show'),30);setTimeout(()=>o.classList.add('leave'),1900);setTimeout(()=>o.remove(),2500)}
function cards(){return COMP.map((c,i)=>{const r=Engine.result(s,i),t=Progress.trend(s,i);return `<div class="card trajectory-card"><div class="trajectory-head"><div><div class="eyebrow">${c[0]}</div><h2>${esc(t.label)}</h2></div><span class="tag">${Engine.quotaText(i)}</span></div>${Progress.chart(s,i)}<div class="trajectory-quick"><p><b>Aktuell:</b> ${esc(r.label)}</p><p><b>Nächster Fokus:</b> ${r.level===3?'Entscheidungslogik begründen und ggf. korrigieren.':'Auf dem nächsten Niveau Wissen in komplexeren Fällen nutzen.'}</p></div><details class="trajectory-details"><summary>Details</summary>${Progress.summary(s,i)}${Progress.table(s,i)}</details></div>`}).join('')}
function beginPractice() {
  const stage = s.stage;
  const targets = Engine.remediationTargets(s, stage);
  if (!targets.length) return;
  s.stageAttempts ??= {1: 0, 2: 0};
  s.stageAttempts[stage] = Number(s.stageAttempts[stage] || 0) + 1;
  s.remediation = targets;
  s.current = null;
  s.hint = 0;
  s.screen = 'task';
  persist();
  render();
  window.scrollTo(0, 0);
}
function returnToCheckpoint() {
  if (!Engine.stageGate(s, s.stage).pass) return;
  s.remediation = [];
  s.current = null;
  s.hint = 0;
  delete s.lastMark;
  s.screen = 'checkpoint';
  persist();
  render();
  window.scrollTo(0, 0);
}
function formatCheckpointScore(score, gate) {
  const percent = score * 100;
  const rounded = Math.round(percent);
  const threshold = gate?.thresholds.overall;
  if (gate?.complete && !gate.pass && rounded >= threshold * 100) {
    const hundredths = Math.min(Math.round(percent * 100), Math.round(threshold * 10000) - 1);
    return (hundredths / 100).toLocaleString('de-DE', { maximumFractionDigits: 2 });
  }
  return rounded;
}
function checkpoint(){const l=s.stage,done=s.rows.length,transfer=l===3?Engine.storyEvaluation(s):null,gate=l<3?Engine.stageGate(s,l):null,passed=l===3?true:gate.pass;
const stageScore = formatCheckpointScore(Engine.stageScore(s,l), gate);
const gateBox=l<3?`<div class="card mastery-gate ${passed?'passed':'locked'}"><div class="mastery-icon">${passed?'✓':'↺'}</div><div><div class="eyebrow">Test-Stufenprüfung</div><h2>${passed?`${LEVEL[l+1]} kann freigeschaltet werden.`:`${LEVEL[l+1]} ist noch gesperrt.`}</h2><p>${passed?'Die Stufenleistung reicht für den nächsten Lernschritt aus.':'Für den Aufstieg brauchst du mindestens <b>66 %</b>. In der Festigungsrunde übst du die Lernziele, bei denen dir Punkte fehlen. Dein bestes Ergebnis je Lernziel zählt.'}</p></div></div>`:'';$('#app').innerHTML=`<div class="card checkpoint-hero"><div><div class="eyebrow">${LEVEL[l]} bearbeitet · ${done}/${TOTAL}</div><h1>${transfer?transfer.label:passed?`${LEVEL[l]} nachgewiesen.`:`${LEVEL[l]} noch nicht sicher nachgewiesen.`}</h1><p>${transfer?'Die Transferwerte stammen aus dem Zusammenspiel deiner 6 Testentscheidungen. Mehrere Wege sind möglich; entscheidend ist die Konsistenz.':passed?'Du hast die Aufgaben dieses Levels ausreichend sicher gelöst.':'Du hast alle Aufgaben dieses Levels bearbeitet. Für den Aufstieg zählt die Qualität deiner Lösungen.'}</p></div><div class="checkpoint-score"><strong>${stageScore} %</strong><span>${transfer?'Beziehungsqualität im Transfer':'Aufgabenergebnis dieses Levels'}</span></div></div>${gateBox}${transfer?`<div class="card transfer-summary compact"><div class="eyebrow">Deine Entscheidungslinie</div><p>${esc(transfer.line)}</p><p><b>${transfer.strongCount} von ${transfer.totalRules}</b> zentralen Verknüpfungen sind besonders stark.</p></div>`:''}${Progress.legend()}<div class="grid">${cards()}</div><div class="actions checkpoint-action">${l < 3 && passed && Engine.remediationTargets(s,l).length ? '<button type="button" id="extraPractice" class="secondary">Offene Lernziele üben</button>' : ''}<button id="continue">${l===3?'Zur Abschlussreflexion':passed?`${LEVEL[l+1]} freischalten`:`${LEVEL[l]} festigen`}</button></div>`;if($('#extraPractice'))$('#extraPractice').onclick=beginPractice;$('#continue').onclick=()=>{if(l<3&&passed){const from=l,to=l+1;s.stage=to;s.screen='task';s.remediation=[];persist();render();stageReveal(from,to)}else if(l<3){beginPractice()}else{s.screen='reflect';persist();render()}window.scrollTo(0,0)}}
function reflect(){
 $('#app').innerHTML=`<div class="card"><div class="eyebrow">30/30 bearbeitet · Abschlussreflexion</div><h1>Wie schätzt du dich jetzt ein?</h1><p>Schätze alle fünf Bereiche noch einmal ein.</p>${selfFields('after')}<div id="selfEndMsg" class="muted"></div><div class="actions"><button id="finish" disabled>Lernweg abschließen</button></div></div>`;
 const check=()=>{const ok=s.after.every(x=>x>=1&&x<=5);$('#finish').disabled=!ok;$('#selfEndMsg').textContent=ok?'✓ Alle fünf Bereiche eingeschätzt.':'Bitte alle fünf Kompetenzbereiche einschätzen.'};
 bindSelf('after',check);check();
 $('#finish').onclick=()=>{for(let c=0;c<5;c++)log(`Selbsteinschaetzung_Ende_${COMP[c][0]}`,`${s.after[c]}/5`,'neutral',c);s.screen='final';set('cmi.core.lesson_status','completed');objectives();persist();render()}
}
function reportHTML(){const ev=Engine.storyEvaluation(s);return `<h1>${esc(PACKAGE.title)} · Lernbericht</h1><p>${s.rows.length}/${TOTAL} Kernaufgaben · Gesamtergebnis ${score()} %. Transfer wird als zusammenhängende Entscheidungslogik bewertet.</p>${ev?`<p><b>Transfer:</b> ${esc(ev.label)}<br>${esc(ev.line)}<br>${ev.strongCount} von ${ev.totalRules} zentralen Verknüpfungen besonders stark.</p>`:''}${COMP.map((c,i)=>`<h2>${c[0]}</h2>${Progress.chart(s,i)}${Progress.summary(s,i)}<p>Selbsteinschätzung: ${s.before[i]||'–'} → ${s.after[i]||'–'} /5</p>`).join('')}`}
function download(){const html=`<!doctype html><html lang="de"><meta charset="utf-8"><title>${esc(PACKAGE.title)} · Lernbericht</title><style>body{font:16px/1.5 Tahoma;margin:40px;color:#20313e}.competence-chart{max-width:700px;width:100%}.checkpoint-stats{display:flex;gap:12px}.checkpoint-stats div{border:1px solid #ddd;padding:10px}</style>${reportHTML()}</html>`;const url=URL.createObjectURL(new Blob([html],{type:'text/html;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download=PACKAGE.id+'_Lernbericht.html';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function finalCurrent(c){const rows=Engine.evidence(s,c).filter(r=>typeof r[1]==='number');return rows.length?rows.reduce((t,r)=>t+r[1],0)/rows.length:0}
function finalBefore(c){return Math.max(0,Math.min(1,Number(s.before[c]||0)/5))}
function finalAfterSelf(c){return Math.max(0,Math.min(1,Number(s.after[c]||0)/5))}
function finalStatus(v){return v>=.85?'sehr stark':v>=.75?'stark':v>=.62?'stabil':v>=.48?'im Aufbau':'weiter festigen'}
function finalFocusText(c) {
 return COMP[c][1];
}
function finalRadar(){const order=[0,3,4,2,1],N=5,cx=250,cy=168,R=120,axes=order.map((_,i)=>-Math.PI/2+i*2*Math.PI/N),pt=(i,v)=>[cx+Math.cos(axes[i])*R*v,cy+Math.sin(axes[i])*R*v],poly=vals=>vals.map((v,i)=>pt(i,v).map(n=>n.toFixed(1)).join(',')).join(' '),before=order.map(i=>finalBefore(i)),after=order.map(i=>finalAfterSelf(i));let grid='';for(const k of [.2,.4,.6,.8,1])grid+=`<polygon points="${poly(Array(5).fill(k))}" fill="none" stroke="#dbe5ea" stroke-width="1"/>`;let axesSvg='';axes.forEach((_,i)=>{const [x,y]=pt(i,1);axesSvg+=`<line x1="${cx}" y1="${cy}" x2="${x}" y2="${y}" stroke="#dbe5ea"/>`});const labelPositions=[[250,20,'middle'],[487,103,'end'],[365,304,'middle'],[135,304,'middle'],[13,103,'start']];return `<svg class="final-radar" viewBox="0 0 500 330" role="img" aria-label="Kompetenznetz: Selbsteinschätzung vor und nach dem Lernweg">${grid}${axesSvg}<polygon points="${poly(before)}" fill="rgba(0,155,217,.10)" stroke="#009bd9" stroke-width="3"/><polygon points="${poly(after)}" fill="rgba(175,202,11,.14)" stroke="#82aa00" stroke-width="4"/>${before.map((v,i)=>{const [x,y]=pt(i,v);return `<circle cx="${x}" cy="${y}" r="5" fill="#009bd9"/>`}).join('')}${after.map((v,i)=>{const [x,y]=pt(i,v);return `<circle cx="${x}" cy="${y}" r="6" fill="#82aa00"/>`}).join('')}${labelPositions.map(([x,y,anchor],i)=>`<text x="${x}" y="${y}" text-anchor="${anchor}" class="radar-label">${esc(COMP[order[i]][0])}</text>`).join('')}</svg><div class="final-radar-legend"><span><i class="legend-line before"></i>vorher · Selbsteinschätzung</span><span><i class="legend-line after"></i>nachher · Selbsteinschätzung</span></div>`}
function finalBars(){const order=[0,3,4,2,1];return order.map(i=>{const c=COMP[i],v=finalCurrent(i),pct=Math.round(v*100);return `<div class="final-comp"><div class="final-comp-name">${esc(c[0])}</div><div class="final-bar" aria-label="${esc(c[0])}: ${pct} Prozent"><span style="height:${Math.max(5,pct)}%"></span></div><div class="final-comp-score">${Math.round(v*5*10)/10} / 5</div><div class="final-comp-status">${finalStatus(v)}</div></div>`}).join('')}
function final(){const ev=Engine.storyEvaluation(s),vals=COMP.map((_,i)=>finalCurrent(i)),focus=vals.indexOf(Math.min(...vals)),selfEnd=s.after[focus]||0,selfPerf=Math.round(vals[focus]*5*10)/10,diff=selfEnd?selfEnd-selfPerf:0,selfNote=!selfEnd?'':Math.abs(diff)<.55?'Deine Selbsteinschätzung passt hier gut zum Leistungsbild.':diff>.55?'Du schätzt dich hier etwas stärker ein als deine Nachweise zeigen.':'Deine Nachweise sind hier stärker als deine eigene Einschätzung.';$('#app').innerHTML=`<div class="final-dashboard"><div class="final-top"><section class="card final-score-card"><div class="eyebrow">Gesamtleistung</div><div class="final-score-ring" style="--score-pct:${score()}%;--score-mid:${Math.round(score()*.55)}%"><strong>${score()} %</strong></div><p>${s.rows.length} von ${TOTAL} Kernaufgaben bearbeitet</p></section><section class="card final-radar-card"><div class="eyebrow">Kompetenznetz · vorher → nachher</div><div class="muted final-radar-note">Deine Selbsteinschätzung vor und nach dem Lernweg.</div>${finalRadar()}</section></div><section class="card final-profile-card"><div class="final-section-head"><h2>Leistungsnachweis · letzter Stand</h2><span>Diese Balken zeigen deine bearbeiteten Aufgaben.</span></div><div class="final-bars">${finalBars()}</div></section><section class="card final-focus-card"><div class="final-focus-icon">◎</div><div class="final-focus-main"><div class="eyebrow">Dein nächster Fokus</div><h2>${esc(COMP[focus][0])}</h2><p>${esc(finalFocusText(focus))}</p></div><div class="final-focus-self"><b>Selbstreflexion</b><span>${selfEnd||'–'} / 5</span><small>${esc(selfNote)}</small></div></section>${ev?`<details class="card final-transfer-details"><summary>Transfer-Feedback zur Entscheidungskette anzeigen</summary><p><b>${esc(ev.label)}</b> · ${esc(ev.line)}</p><p>${esc(ev.correctionText)}</p><p><b>Nächster Schritt:</b> ${esc(ev.feedforward)}</p></details>`:''}<div class="actions final-actions"><button id="download">Lernbericht herunterladen</button></div></div>`;$('#download').onclick=download}
function render(){updateChrome();status();if(legacyAttempt){$('#app').innerHTML='<div class="card"><h1>Neuer Versuch erforderlich</h1><p>Diese Fassung nutzt leistungsabhängige Stufenaufstiege. Ein alter Versuch wird nicht neu bewertet. Bitte einen neuen Moodle-Versuch starten.</p></div>';return}if(s.screen==='intro')intro();else if(s.screen==='checkpoint')checkpoint();else if(s.screen==='reflect')reflect();else if(s.screen==='final')final();else if(s.screen==='feedback' && Number.isFinite(s.lastMark) && BANK[s.current]) {
    const question = BANK[s.current];
    $('#app').innerHTML = `<section class="card"><h1>${esc(question.title)}</h1><p>${esc(question.ask)}</p><div id="feedback"></div></section>`;
    showStandardFeedback(question, s.lastMark);
  } else { if(s.screen==='feedback')s.hint=0;task(); }}
function closeSession(){if(finished||!initialized)return;persist();const sec=Math.floor((Date.now()-start)/1000);set('cmi.core.session_time',`${String(Math.floor(sec/3600)).padStart(4,'0')}:${String(Math.floor(sec%3600/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`);set('cmi.core.exit',s.screen==='final'?'':'suspend');try{api.LMSCommit('');api.LMSFinish('')}catch(e){}finished=true}
window.addEventListener('pagehide',closeSession);window.addEventListener('beforeunload',closeSession);render();
