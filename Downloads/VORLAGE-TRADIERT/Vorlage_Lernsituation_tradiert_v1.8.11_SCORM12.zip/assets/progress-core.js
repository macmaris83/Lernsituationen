/* Tradiert: W1 only; existing task identities are retained. */
(()=>{'use strict';
const phases=['informieren','planen','entscheiden','durchfuehren','bewerten','reflektieren'];
const clone=x=>JSON.parse(JSON.stringify(x));
function hash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(16).padStart(8,'0');}
const text=e=>(e.textContent||'').replace(/\s+/g,' ').trim();
function availableModes(meta){return [...new Set(Object.values(meta.tasks||{}).map(t=>Number(t.mode)))].filter(n=>Number.isInteger(n)&&n>0).sort((a,b)=>a-b);}
function initial(meta,mode){return {s:1,l:meta.id,m:availableModes(meta).includes(Number(mode))?Number(mode):(availableModes(meta)[0]||1),t:{},o:false,w:meta.orientationSignature,q:{},v:meta.quizSignature,b:'index.html',a:{assessments:{},feedback:'',nextGoal:''},r:null};}
function sanitize(raw,meta,mode){const p=initial(meta,mode);if(!raw||raw.s!==1||raw.l!==meta.id)return p;p.m=Number.isInteger(raw.m)&&availableModes(meta).includes(raw.m)?raw.m:p.m;for(const [k,v]of Object.entries(raw.t||{})){if(meta.tasks[k]?.signature===v)p.t[k]=v;}p.o=raw.o===true&&raw.w===p.w;if(raw.v===p.v)for(const q of meta.quiz){const a=raw.q?.[q.id];if(Array.isArray(a)&&q.options.includes(a[0])&&typeof a[1]==='boolean')p.q[q.id]=[a[0],a[1]];}if(meta.resumePages.includes(raw.b))p.b=raw.b;for(const c of meta.competencies||[]){const a=raw.a?.assessments?.[c.id]||{};p.a.assessments[c.id]={after:Number.isInteger(a.after)&&a.after>=1&&a.after<=4?a.after:null,evidence:String(a.evidence||'')};}p.a.feedback=String(raw.a?.feedback||'');p.a.nextGoal=String(raw.a?.nextGoal||'');if(Number.isInteger(raw.r)&&raw.r>=0&&raw.r<=100000)p.r=raw.r;return p;}
function phaseComplete(p,meta,phase,mode=p.m){const ts=Object.entries(meta.tasks).filter(([,t])=>t.phase===phase&&t.mode===Number(mode));return ts.length>0&&ts.every(([k,t])=>p.t[k]===t.signature);}
function quizComplete(p,meta){return meta.quiz.length>0&&p.v===meta.quizSignature&&meta.quiz.every(q=>p.q[q.id]?.[0]===q.correct&&p.q[q.id]?.[1]===true);}
function blockedBy(p,meta,page,mode=p.m){
 const index=phases.indexOf(page.replace('.html',''));
 if(index<0)return null;
 if(!quizComplete(p,meta))return 'handlungssituation';
 for(const phase of phases.slice(0,index))if(!phaseComplete(p,meta,phase,mode))return phase;
 return null;
}
function allComplete(p,meta){return p.o&&p.w===meta.orientationSignature&&quizComplete(p,meta)&&phases.every(x=>phaseComplete(p,meta,x));}
function setTask(p,meta,k,done){if(!meta.tasks[k])return;if(done)p.t[k]=meta.tasks[k].signature;else delete p.t[k];}
function decorate(root,phase){for(const panel of root.querySelectorAll('[data-mode-panel]')){const mode=Number(panel.dataset.modePanel);let number=0;for(const a of panel.querySelectorAll('.assignment-frame')){number++;const body=a.querySelector('.assignment-body');if(!body)throw Error('Auftragsinhalt fehlt.');const id=phases.indexOf(phase)+':'+mode+':'+number;a.dataset.taskId=id;a.dataset.taskSignature=hash(text(body));let label=a.querySelector('[data-completion-label]');if(!label){label=root.ownerDocument.createElement('label');label.className='task-completion no-print';label.dataset.completionLabel='';label.setAttribute('contenteditable','false');label.innerHTML='<input type="checkbox" data-task-complete><span class="sr-only">Aufgabe erledigt</span>';a.appendChild(label);}const input=label.querySelector('input');input.dataset.taskId=id;input.setAttribute('aria-label','Aufgabe '+number+' als erledigt markieren');input.removeAttribute('checked');input.setAttribute('disabled','');input.checked=false;}}
}
function singlePathHTML(source,parser){
 const doc=(parser||new DOMParser()).parseFromString('<div>'+source+'</div>','text/html'),template=doc.body.firstElementChild;let changed=false;
 for(const el of template.querySelectorAll('[data-mode-panel]'))if(Number(el.dataset.modePanel)!==1){el.remove();changed=true;}
 for(const select of template.querySelectorAll('[data-student-mode],[data-teacher-mode]'))for(const option of [...select.options])if(Number(option.value)!==1){option.remove();changed=true;}
 return changed?template.innerHTML:source;
}
function metadataFrom(data,parser){for(const page of Object.keys(data.pages))data.pages[page]=singlePathHTML(data.pages[page],parser);const tasks={};for(const phase of phases){const doc=parser.parseFromString('<div>'+data.pages[phase+'.html']+'</div>','text/html');decorate(doc.body,phase);for(const a of doc.querySelectorAll('.assignment-frame')){const k=a.dataset.taskId;tasks[k]={phase,mode:Number(a.closest('[data-mode-panel]').dataset.modePanel),signature:a.dataset.taskSignature};}data.pages[phase+'.html']=doc.body.firstElementChild.innerHTML;}
 const modes=availableModes({tasks});if(modes.length!==1||modes[0]!==1)throw Error('Der tradierte Lernweg fehlt.');for(const phase of phases)for(const mode of modes)if(!Object.values(tasks).some(t=>t.phase===phase&&t.mode===mode))throw Error('Aufträge fehlen in '+phase+', Lernweg '+mode+'.');
 const doc=parser.parseFromString('<div>'+data.pages['handlungssituation.html']+'</div>','text/html');const payload=doc.querySelector('[data-situation-quiz] script[type="application/json"]');const qs=payload?JSON.parse(payload.textContent):[];if(!qs.length)throw Error('Der Kurztest der Handlungssituation fehlt.');const quiz=qs.map(q=>({id:q.id,correct:q.correct,options:q.options.map(a=>a.value)}));
 const index=parser.parseFromString('<div>'+data.pages['index.html']+'</div>','text/html');if(!index.querySelector('[data-orientation-completion]')){const el=index.createElement('section');el.className='orientation-completion no-print';el.dataset.orientationCompletion='';el.setAttribute('contenteditable','false');el.innerHTML='<label><input type="checkbox" data-orientation-complete>Orientierung gelesen</label><p class="progress-counter" data-progress-status role="status"></p>';index.body.firstElementChild.appendChild(el);}index.querySelectorAll('[data-orientation-complete]').forEach(e=>{e.removeAttribute('checked');e.setAttribute('disabled','');e.checked=false;});data.pages['index.html']=index.body.firstElementChild.innerHTML;index.querySelectorAll('[data-orientation-completion]').forEach(e=>e.remove());
 return {id:data.id,availableModes:modes,competencies:data.competencies.map(c=>({id:c.id,label:c.label})),tasks,quiz,quizSignature:hash(JSON.stringify(qs)),orientationSignature:hash(text(index.body)),resumePages:Object.keys(data.pages).filter(p=>!['lehrkraft.html','erwartungshorizont.html','druckansicht.html'].includes(p))};}
window.SOZ_PROGRESS_CORE={singlePathHTML,availableModes,phases,clone,hash,text,initial,sanitize,phaseComplete,quizComplete,blockedBy,allComplete,setTask,decorate,metadataFrom};
})();
