(()=>{'use strict';

const D=window.SOZPAED,C=window.SOZ_CONFIG||{},MEDIA=window.SOZ_MEDIA||{};
if(!D)return;
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const version=D.version,key=`sozpaed:${D.id}:${version}`+(window.SOZ_PROGRESS?.learner?':student:'+encodeURIComponent(window.SOZ_PROGRESS.learner):':preview'),settingKey=key+':settings:'+(C.packageRevision||'base')+':'+location.pathname.replace(/[^/]+$/,''),labels=['','Tradiert · stark geführt','Geführt','Begleitet','Teiloffen','Löppt'];
const blank=()=>({schema:1,lesson:D.id,version,assessments:{},work:{},feedback:'',nextGoal:''});
let state=blank(),settings={mode:1,allowStudentMode:false,moodle:{},media:{},overrides:{},...C},storageOK=true;
try{const x=localStorage.getItem(key);if(x)state=validateState(JSON.parse(x));const s=JSON.parse(localStorage.getItem(settingKey)||'null');if(s)settings={...settings,...s,media:{...(C.media||{}),...(s.media||{})}};}catch(e){storageOK=false;}
if(window.SOZ_PROGRESS&&!document.body.dataset.teacher){settings.mode=window.SOZ_PROGRESS.initialMode;const a=window.SOZ_PROGRESS.read().a;if(a){state.assessments=a.assessments;state.feedback=a.feedback;state.nextGoal=a.nextGoal;}}
function validateState(s){if(!s||s.schema!==1||s.lesson!==D.id||s.version!==version)throw Error('Diese Datei gehört zu einer anderen Lernsituation oder Version.');const out=blank();for(const c of D.competencies){const a=s.assessments?.[c.id]||{};for(const f of ['after'])if(a[f]!==undefined&&a[f]!==null&&(!Number.isInteger(a[f])||a[f]<1||a[f]>4))throw Error('Es sind nur Werte von 1 bis 4 oder leere Werte zulässig.');out.assessments[c.id]={after:a.after??null,evidence:String(a.evidence||'').slice(0,20000)};}if(!s.work||typeof s.work==='object'){for(const [k,v]of Object.entries(s.work||{}))if(typeof v==='string'||typeof v==='boolean')out.work[k]=v;}out.feedback=String(s.feedback||'').slice(0,20000);out.nextGoal=String(s.nextGoal||'').slice(0,20000);return out;}
function status(text){$$('[data-save-message]').forEach(e=>e.textContent=text);}
function assessmentStatus(){const p=window.SOZ_PROGRESS;if(p?.kind==='moodle')return p.readOnly?'Ansichtsmodus: Gespeicherte Angaben sind schreibgeschützt.':p.storageMessage;return storageOK?'Auf diesem Gerät im Browser gespeichert.':'Speichern im Browser ist gesperrt.';}
function save(){if(window.SOZ_PROGRESS?.readOnly){status(assessmentStatus());return false;}try{localStorage.setItem(key,JSON.stringify(state));storageOK=true;}catch{storageOK=false;}const p=window.SOZ_PROGRESS;if(p&&!document.body.dataset.teacher){const next=p.read();next.a={assessments:state.assessments,feedback:state.feedback,nextGoal:state.nextGoal};const ok=p.write(next);status(assessmentStatus());return ok;}status(assessmentStatus());return storageOK;}
function saveSettings(){const stored={...settings,media:{}};for(const [id,value]of Object.entries(settings.media||{})){if(JSON.stringify(value)!==JSON.stringify(C.media?.[id]))stored.media[id]=value;}try{localStorage.setItem(settingKey,JSON.stringify(stored));}catch(e){const notice=document.querySelector("[data-teacher-status]");if(notice)notice.textContent="Browserspeicher voll: Änderungen jetzt als SCORM exportieren, bevor die Seite geschlossen wird.";}window.SOZ_ACTIVE_CONFIG=settings;}
function safeURL(s){try{const u=new URL(s);return /^https?:$/.test(u.protocol)?u.href:'';}catch{return '';}}
function modes(){return Object.keys(settings.learningPaths||{}).map(Number).filter(n=>Number.isInteger(n)&&n>0).sort((a,b)=>a-b);}
function setMode(mode,store=true){mode=Number(mode);const available=modes();if(!available.includes(mode))mode=available[0]||1;settings.mode=mode;document.body.dataset.mode=mode;$$('[data-mode-panel]').forEach(e=>e.hidden=Number(e.dataset.modePanel)!==mode);$$('[data-mode-label]').forEach(e=>e.textContent=settings.learningPaths[mode]?.label||String(mode));$$('[data-student-mode]').forEach(e=>{e.replaceChildren();for(const id of available){const option=document.createElement('option');option.value=id;option.textContent=settings.learningPaths[id].label;e.append(option);}e.value=mode;e.parentElement.hidden=available.length<2||!settings.allowStudentMode;});if(store)saveSettings();if(!document.body.dataset.teacher)window.SOZ_PROGRESS?.setMode(mode);}
const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function options(value){return `<option value="">Noch offen</option>`+[1,2,3,4].map(n=>`<option value="${n}"${n===value?' selected':''}>${n}</option>`).join('');}
function assessmentUI(root){root.innerHTML=`<section class="card assessment-final"><h2>Mein Kompetenzcheck nach der Lernsituation</h2><p>Schätze dich nach dieser Lernsituation anhand der fünf Ich-Aussagen ein. Noch nicht beurteilbare Werte bleiben offen.</p><p class="assessment-note"><b>1</b> = mit enger Hilfe · <b>2</b> = mit einzelnen Hilfen · <b>3</b> = selbstständig im bekannten Fall · <b>4</b> = selbstständig und begründet im Transfer.</p><div class="weight-radar assessment-radar" data-radar></div><p>Das Netz zeigt deine Einschätzung nach der Lernsituation. Offene Werte werden nicht als Null dargestellt. Ergänze zu deinen Werten einen kurzen Arbeitsbeleg.</p><div class="table-scroll"><table class="check-table"><thead><tr><th>Kompetenz / Ich-Aussage</th><th>Einschätzung nach der LS · 1–4</th><th>Mein konkreter Beleg</th></tr></thead><tbody>${D.competencies.map(c=>{const a=state.assessments[c.id]||{};return `<tr><th scope="row">${escape(c.label)}<br><small>${escape(c.id)}</small><p style="font-weight:400">${escape(c.statement)}</p></th><td><select aria-label="${c.id} Einschätzung nach der LS" data-assess="after" data-comp="${c.id}">${options(a.after)}</select></td><td><textarea maxlength="255" aria-label="${c.id} Beleg" data-assess="evidence" data-comp="${c.id}">${escape(a.evidence||'')}</textarea><small>Kurzer Beleg · höchstens 255 Zeichen</small><small data-evidence-warning="${c.id}"></small></td></tr>`}).join('')}</tbody></table></div><details class="feedback"><summary>Fremdfeedback getrennt dokumentieren</summary><p>Rückmeldung, gebende Person und Datum:</p><textarea maxlength="255" data-extra="feedback" aria-label="Fremdfeedback">${escape(state.feedback)}</textarea><small>Höchstens 255 Zeichen</small></details><label>Nächster persönlicher Lernschritt<textarea maxlength="255" data-extra="nextGoal">${escape(state.nextGoal)}</textarea><small>Höchstens 255 Zeichen</small></label><div class="assessment-controls no-print"><button data-reset-state>Diese LS zurücksetzen</button><button data-retry-assessment>Erneut in Moodle speichern</button></div><p data-save-message class="save-message" role="status" aria-live="polite"></p><p class="muted" data-assessment-storage-note></p></section>`;
const readOnly=!!window.SOZ_PROGRESS?.readOnly;
$$('[data-assess],[data-extra],[data-reset-state],[data-retry-assessment]',root).forEach(e=>e.disabled=readOnly);
$$('[data-assess]',root).forEach(e=>e.addEventListener('input',()=>{const id=e.dataset.comp;const a=state.assessments[id]||(state.assessments[id]={after:null,evidence:''});a[e.dataset.assess]=e.dataset.assess==='evidence'?e.value:e.value===''?null:Number(e.value);save();drawRadars();}));
$$('[data-extra]',root).forEach(e=>e.addEventListener('input',()=>{state[e.dataset.extra]=e.value;save();}));
$('[data-reset-state]',root)?.addEventListener('click',()=>{if(confirm('Alle eigenen Eingaben und Aufgabenhaken dieser Lernsituation zurücksetzen?')){const p=window.SOZ_PROGRESS;if(p&&!p.reset()){status(p.storageMessage);return;}state=blank();try{localStorage.setItem(key,JSON.stringify(state));}catch{}location.reload();}});
$('[data-retry-assessment]',root)?.addEventListener('click',save);
const moodle=window.SOZ_PROGRESS?.kind==='moodle';$('[data-retry-assessment]',root).hidden=!moodle;
$('[data-assessment-storage-note]',root).textContent=moodle?'Deine Einschätzungen, Belege und Reflexionstexte werden in deinem Moodle-Versuch gespeichert und sind für die Lehrkraft im SCORM-Bericht einsehbar. Die Selbsteinschätzung wird nicht benotet.':'Lokale Vorschau: Deine Angaben werden nur in diesem Browser gespeichert. Öffne das Lernpaket in Moodle, um sie in deinem Schülerkonto zu speichern.';
}
function drawRadars(){const cx=350,cy=215,r=155,labels=['Fachkompetenz','Personalkompetenz','Sozialkompetenz','Methodenkompetenz','Medienkompetenz'];let grid='',data='';const pt=(i,v)=>{const a=(i*72-90)*Math.PI/180;return [cx+Math.cos(a)*r*v/4,cy+Math.sin(a)*r*v/4];};
for(let v=1;v<=4;v++)grid+=`<polygon points="${D.competencies.map((_,i)=>pt(i,v).join(',')).join(' ')}" fill="none" stroke="#c8dce7"/>`;
D.competencies.forEach((c,i)=>{const p=pt(i,4),t=pt(i,5.03);grid+=`<line x1="${cx}" y1="${cy}" x2="${p[0]}" y2="${p[1]}" stroke="#d2e3ea"/><text x="${t[0]}" y="${t[1]}" text-anchor="middle" dominant-baseline="middle" fill="#173a63" font-size="15">${escape(labels[i]||c.label)}</text>`;});
const vs=D.competencies.map(c=>state.assessments[c.id]?.after??null);
if(vs.every(v=>v!==null))data+=`<polygon class="weight-polygon" points="${vs.map((v,i)=>pt(i,v).join(',')).join(' ')}" fill="#afca0b" fill-opacity=".27" stroke="#009bd9" stroke-width="2.5"/>`;
else for(let i=0;i<vs.length;i++){const j=(i+1)%vs.length;if(vs[i]!==null&&vs[j]!==null){const a=pt(i,vs[i]),b=pt(j,vs[j]);data+=`<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="#009bd9" stroke-width="2.5"/>`;}}
vs.forEach((v,i)=>{if(v!==null){const p=pt(i,v);data+=`<circle cx="${p[0]}" cy="${p[1]}" r="4.5" fill="white" stroke="#009bd9" stroke-width="2"/>`;}});
for(let v=1;v<=4;v++)grid+=`<text x="357" y="${cy-r*v/4+4}" font-size="11" fill="#617988">${v}</text>`;
const desc=D.competencies.map((c,i)=>c.label+': '+(vs[i]===null?'noch offen':vs[i]+' von 4')).join('; ');
$$('[data-radar]').forEach(e=>e.innerHTML=`<svg viewBox="0 0 700 435" role="img" aria-label="Kompetenznetz nach der Lernsituation"><title>Meine Selbsteinschätzung nach der Lernsituation</title><desc>${escape(desc)}</desc>${grid}${data}</svg>`);
$$('[data-evidence-warning]').forEach(e=>{const a=state.assessments[e.dataset.evidenceWarning]||{};e.textContent=a.after&&!String(a.evidence||'').trim()?'Bitte noch einen Arbeitsbeleg ergänzen.':'';});}
function blobDownload(blob,name){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);}
function renderMedia(){for(const el of $$('[data-media-key]')){const k=el.dataset.mediaKey;const m={...(MEDIA.slots?.[k]||{}),...(settings.media?.[k]||{})};const src=m.src;if(src&&(/^(assets\/|data:image\/(png|jpeg|webp|gif);base64,)/.test(src))){el.innerHTML=`<img src="${escape(src)}" alt="${escape(m.alt||m.label||'Abbildung zur Lernsituation')}"><figcaption>${escape(m.caption||m.alt||'')}</figcaption>`;const det=el.closest('details.optional-image');if(det)det.open=true;}}}
function bindMoodle(){for(const e of $$('[data-moodle-action]')){const url=safeURL(settings.moodle?.[e.dataset.moodleAction]||'');if(url){const a=document.createElement('a');a.href=url;a.className='button';a.target='_blank';a.rel='noopener';a.textContent=e.dataset.moodleAction==='reflection-submit'?'Persönliche Reflexion abgeben':'Überarbeitetes Produkt abgeben';e.replaceChildren(a);} }}
function bindWork(){const page=document.body.dataset.page;$$('input[data-work-surface],textarea[data-work-surface],[contenteditable=true][data-work-surface]').forEach((e,i)=>{const k=page+':'+(e.dataset.workId||i);if(k in state.work){if(e.type==='checkbox')e.checked=state.work[k];else if(e.hasAttribute('contenteditable'))e.textContent=state.work[k];else e.value=state.work[k];}e.addEventListener('input',()=>{state.work[k]=e.type==='checkbox'?e.checked:e.hasAttribute('contenteditable')?e.textContent:e.value;save();});});}
async function loadScript(src){if($(`script[src="${src}"]`))return;await new Promise((ok,no)=>{const e=document.createElement('script');e.src=src;e.onload=ok;e.onerror=no;document.head.append(e);});}
async function shareWorkbook(){try{const response=await fetch(D.workbook,{credentials:'same-origin'});if(!response.ok)throw Error('Arbeitsheft nicht erreichbar.');const bytes=new Uint8Array(await response.arrayBuffer());const f=new File([bytes],D.workbook.split('/').pop(),{type:'application/pdf'});if(navigator.canShare?.({files:[f]})){await navigator.share({files:[f],title:'Arbeitsheft · LS '+D.id});}else blobDownload(f,f.name);}catch(e){if(e.name!=='AbortError')window.open(D.workbook,'_blank');}}
function bindProgress(){window.SOZ_PROGRESS?.render();}

function start(){const page=document.body.dataset.page;const content=$('.lesson-content');if(settings.overrides?.[page]&&content&&!document.body.dataset.teacher)content.innerHTML=settings.overrides[page];if(page==='druckansicht.html'){const out=$('[data-print-content]');out.innerHTML=D.printOrder.map(name=>`<article class="print-chapter" data-print-source="${name}"><header class="print-heading">LS ${D.id} · ${escape(D.pageTitles[name])}</header>${settings.overrides?.[name]||D.pages[name]||''}</article>`).join('');$$('[data-delayed-material]',out).forEach(e=>e.hidden=true);if(new URLSearchParams(location.search).get('teacher')==='1')out.insertAdjacentHTML('beforeend',`<article class="print-chapter">${D.pages['erwartungshorizont.html']}</article>`);}
$$('[data-assessment-widget]').forEach(assessmentUI);drawRadars();bindProgress();setMode(settings.mode,false);$$('[data-student-mode]').forEach(e=>e.addEventListener('change',()=>setMode(e.value)));renderMedia();bindMoodle();bindWork();$$('[data-share-workbook]').forEach(e=>e.addEventListener('click',shareWorkbook));$$('[data-print]').forEach(e=>e.addEventListener('click',async()=>{await document.fonts.ready;await Promise.all([...document.images].map(image=>image.decode().catch(()=>{})));window.print();}));status(assessmentStatus());$$('[data-release-material]').forEach(e=>e.addEventListener('click',()=>{const target=$('[data-delayed-material]');if(target){target.hidden=false;e.hidden=true;}}));window.SOZ_PROGRESS?.mount();status(assessmentStatus());window.SOZ_READY=true;}
window.SOZ_API={availableModes:modes,getState:()=>state,getSettings:()=>settings,setMode,bindProgress,saveSettings,validateState,safeURL,blobDownload,loadScript,renderMedia,escape,version,key,labels};
start();
})();

/* Einfache Aufgabenauswahl mit ausdrücklicher Erledigt-Markierung. */
(()=>{'use strict';
if(document.body.dataset.teacher||!document.body.dataset.phaseLayout)return;
const P=window.SOZ_PROGRESS;if(!P)return;
for(const panel of document.querySelectorAll('section.task-card[data-mode-panel]')){
 const cards=[...panel.querySelectorAll('.assignment-frame')];if(!cards.length)continue;
 const checkbox=card=>card.querySelector('[data-task-complete]');
 let selected=cards.find(card=>!checkbox(card)?.checked)||null;
 const status=document.createElement('p');status.className='task-guide-status no-print';status.setAttribute('role','status');panel.append(status);
 function draw(){for(const card of cards){const active=card===selected;card.classList.toggle('task-selected',active);card.setAttribute('aria-label','Aufgabe '+card.dataset.taskNumber+(active?' · ausgewählt':''));}status.textContent=selected?'Aufgabe '+selected.dataset.taskNumber+': Markiere sie als gelöst, wenn du sie bearbeitet hast.':'Alle Aufgaben dieses Lernwegs sind als gelöst markiert.';}
 for(const card of cards){
  card.tabIndex=0;card.setAttribute('role','group');
  const input=checkbox(card),label=card.querySelector('[data-completion-label]');
  const text=label?.querySelector('.sr-only');if(text){text.classList.add('task-solved-text');text.classList.remove('sr-only');text.textContent='Aufgabe gelöst';}
  input?.setAttribute('aria-label','Aufgabe '+card.dataset.taskNumber+' als gelöst markieren');
  const select=()=>{selected=card;draw();};
  card.addEventListener('click',event=>{if(event.target.closest('a,button,input,label,details,textarea,select'))return;select();});
  card.addEventListener('keydown',event=>{if(event.target===card&&(event.key==='Enter'||event.key===' ')){event.preventDefault();select();}});
  input?.addEventListener('change',()=>{if(input.checked){const index=cards.indexOf(card);selected=cards.slice(index+1).find(c=>!checkbox(c)?.checked)||cards.find(c=>!checkbox(c)?.checked)||null;}else selected=card;draw();});
 }
 draw();
}
document.body.dataset.taskGuideReady='true';
})();

(()=>{'use strict';
const D=window.SOZPAED;if(!D||document.body.dataset.teacher||document.body.dataset.page==='druckansicht.html')return;
const key='soz-task-return:'+D.id+':'+location.pathname.replace(/[^/]+$/,'');let saved=null;
try{saved=JSON.parse(sessionStorage.getItem(key)||'null');}catch{}
const page=document.body.dataset.page,phases=['informieren','planen','entscheiden','durchfuehren','bewerten','reflektieren'];
if(!document.body.dataset.phaseLayout){if(/^m\d+\.html$/.test(page||''))document.body.classList.add('material-reading');
 if(/^m\d+\.html$/.test(page||'')&&saved&&phases.includes(saved.page.replace('.html',''))&&window.SOZ_PROGRESS_META.tasks[saved.task]){
 const a=document.createElement('a');a.className='button return-task';a.textContent='← Zurück zu Aufgabe '+saved.number;a.href=saved.page+'?aufgabe='+encodeURIComponent(saved.task)+'#task-'+saved.task.replaceAll(':','-');document.querySelector('.main')?.prepend(a);}
 return;
}
const clocks=new Map();let current=null,interval=null;const clockKey=key+':clocks';let savedClocks={};try{savedClocks=JSON.parse(sessionStorage.getItem(clockKey)||'{}');}catch{};function saveClocks(){try{sessionStorage.setItem(clockKey,JSON.stringify(Object.fromEntries([...clocks.values()].map(t=>[t.card.dataset.taskId,t.remaining]))));}catch{}}
function paint(t){const f=1-t.remaining/t.total,m=f<=.5?f*2:(f-.5)*2,a=f<=.5?[175,202,11]:[17,17,17],b=f<=.5?[17,17,17]:[180,35,24];
 t.display.textContent=String(Math.floor(t.remaining/60)).padStart(2,'0')+':'+String(t.remaining%60).padStart(2,'0');t.display.style.color='rgb('+a.map((v,i)=>Math.round(v+(b[i]-v)*m)).join(',')+')';t.pause.hidden=t.remaining===0;t.pause.textContent=t.running?'Pause':'Fortsetzen';t.note.textContent=t.remaining?'Die Zeit ist eine Orientierung. Du kannst pausieren und weiterarbeiten.':'🔔 Orientierungszeit erreicht. Du kannst weiterarbeiten.';}
function tick(t){if(t.running){t.remaining=Math.max(0,Math.ceil((t.deadline-Date.now())/1000));if(!t.remaining)t.running=false;}paint(t);}
function stop(){if(current){tick(current);current.running=false;paint(current);}clearInterval(interval);interval=null;saveClocks();}
for(const card of document.querySelectorAll('.assignment-frame')){
 card.id='task-'+card.dataset.taskId.replaceAll(':','-');
 const match=card.querySelector('.assignment-time')?.textContent.match(/(\d+)\s*Min/i);if(!match)continue;
 const total=Number(match[1])*60,holder=document.createElement('aside');holder.className='task-inline-timer no-print';holder.hidden=true;
 const row=document.createElement('div');row.className='task-timer-row';row.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/></svg>';
 const display=document.createElement('span');display.className='task-timer-digits';display.setAttribute('role','timer');
 const pause=document.createElement('button');pause.type='button';pause.textContent='Pause';row.append(display,pause);
 const note=document.createElement('p');note.setAttribute('role','status');holder.append(row,note);card.append(holder);
 const t={card,holder,display,pause,note,total,remaining:Number.isInteger(savedClocks[card.dataset.taskId])?Math.max(0,Math.min(total,savedClocks[card.dataset.taskId])):total,running:false,deadline:0};clocks.set(card,t);paint(t);
 pause.addEventListener('click',()=>{if(t.running){tick(t);t.running=false;clearInterval(interval);interval=null;}else if(t.remaining){t.deadline=Date.now()+t.remaining*1000;t.running=true;interval=setInterval(()=>tick(t),200);}paint(t);});
}
function sync(){const card=[...document.querySelectorAll('.task-selected')].find(c=>!c.closest('[data-mode-panel]').hidden);const next=clocks.get(card)||null;if(current===next)return;stop();if(current)current.holder.hidden=true;current=next;
 if(card)try{sessionStorage.setItem(key,JSON.stringify({page,task:card.dataset.taskId,number:card.dataset.taskNumber}));}catch{}
 if(current){current.holder.hidden=false;if(current.remaining){current.deadline=Date.now()+current.remaining*1000;current.running=true;interval=setInterval(()=>tick(current),200);}paint(current);}
}
const requested=new URLSearchParams(location.search).get('aufgabe');
if(requested){const card=[...document.querySelectorAll('.assignment-frame')].find(c=>c.dataset.taskId===requested);if(card){card.dispatchEvent(new MouseEvent('click',{bubbles:true}));requestAnimationFrame(()=>{card.scrollIntoView({block:'center'});card.focus({preventScroll:true});});}}
new MutationObserver(sync).observe(document.querySelector('.lesson-content'),{subtree:true,attributes:true,attributeFilter:['class']});sync();window.addEventListener('pagehide',stop);document.body.dataset.taskReturnReady='true';
})();
