BioCasa LG01 · LS04-Rollenspielrevision

LS04: Version 1.8 – Bei Business Angels pitchen. LS05 und LS06 bleiben unverändert in Version 1.7.

Sammelarchiv entpacken und die Einzel-ZIP in der jeweils zugehörigen bestehenden Moodle-SCORM-Aktivität ersetzen.

In LS04 spielt jede Person aktiv beide Rollen: eigener Beitrag im Gruppenpitch und in der anderen Runde eigene Frage und Beobachtung als Business Angel. Die bestehenden Drei- bis Vierergruppen bleiben zusammen. Zwei Lehrkräfte beurteilen unter Einbeziehung des begründeten Peerfeedbacks.

Die Kennungen dieser eigenständigen Lieferung LG01-LS04 usw. entsprechen nicht den BRC-LG01-…-Kennungen der regulären Katalogreihe.
