BioCasa LG01 · Version 1.7

Dieses Sammelarchiv entpacken. In Moodle jeweils die enthaltene Einzel-ZIP in der zugehörigen bestehenden SCORM-Aktivität ersetzen.

Das Gesamtdokument im Paket liegt unter pdf/Gesamtdokument_A4.pdf. Die Drucker-Schaltfläche öffnet die aktuelle Druckansicht einschließlich gespeicherter Bearbeitungen.

Diese Lieferung verwendet die ursprünglichen Kennungen LG01-LS01 bis LG01-LS06. Die Katalogreihe BRC-LG01-… verwendet eigene Kennungen.
